
import React from 'react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const ViewUserDialog = ({ user, isOpen, onClose }) => {
  if (!isOpen || !user) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>รายละเอียดผู้ใช้: {user.username}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-4">
          <p><strong>ID:</strong> {user.id}</p>
          <p><strong>ชื่อผู้ใช้:</strong> {user.username}</p>
          <p><strong>อีเมล:</strong> {user.email}</p>
          <p><strong>ชื่อ-นามสกุล:</strong> {user.fullName || '-'}</p>
          <p><strong>เบอร์โทร:</strong> {user.phoneNumber || '-'}</p>
          <p><strong>ยอดเงิน:</strong> ฿{user.balance.toLocaleString()}</p>
          <p><strong>วันที่สมัคร:</strong> {new Date(user.createdAt).toLocaleString('th-TH')}</p>
          <h4 className="font-semibold pt-2">รายการล่าสุด (5):</h4>
          {user.transactions && user.transactions.length > 0 ? (
            <div className="space-y-2 max-h-40 overflow-y-auto text-sm pr-2">
              {user.transactions.slice(0, 5).map(tx => (
                <div key={tx.id} className="flex justify-between items-center p-2 bg-muted/50 rounded">
                  <div>
                    <span className="capitalize">{tx.type} {tx.type === 'game' ? `(${tx.gameName})` : ''}</span>
                    <span className="block text-xs text-muted-foreground">{new Date(tx.timestamp).toLocaleString('th-TH')}</span>
                  </div>
                  <span className={`font-medium ${tx.type === 'deposit' || (tx.type === 'game' && tx.result === 'win') ? 'text-green-500' : tx.type === 'withdraw' || (tx.type === 'game' && tx.result === 'lose') ? 'text-red-500' : ''}`}>
                    {tx.type === 'deposit' ? `+฿${tx.amount.toLocaleString()}` :
                     tx.type === 'withdraw' ? `-฿${tx.amount.toLocaleString()}` :
                     tx.result === 'win' ? `+฿${tx.winAmount.toLocaleString()}` : `-฿${tx.betAmount.toLocaleString()}`}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">ไม่มีรายการ</p>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>ปิด</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ViewUserDialog;
