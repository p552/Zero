
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Loader2 } from 'lucide-react';

const EditUserDialog = ({ user, isOpen, onClose, onSave }) => {
  const [editingData, setEditingData] = useState(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setEditingData({ ...user });
    } else {
      setEditingData(null);
    }
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditingData(prev => ({ ...prev, [name]: value }));
  };

  const handleBalanceChange = (e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) { // Allow decimals for balance
      setEditingData(prev => ({ ...prev, balance: value === '' ? '' : parseFloat(value) }));
    }
  };

  const handleSaveChanges = async () => {
    if (!editingData) return;
    setIsSaving(true);
    try {
      await onSave(editingData); // Call the passed onSave function
      onClose(); // Close dialog on successful save
    } catch (error) {
      console.error("Failed to save user changes:", error);
      // Error toast should be handled by the parent component or hook
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen || !editingData) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>แก้ไขข้อมูลผู้ใช้</DialogTitle>
          <DialogDescription>
            ทำการเปลี่ยนแปลงข้อมูลของผู้ใช้ "{editingData.username}"
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="edit-username" className="text-right">ชื่อผู้ใช้</Label>
            <Input id="edit-username" name="username" value={editingData.username} onChange={handleInputChange} className="col-span-3" disabled={isSaving} />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="edit-email" className="text-right">อีเมล</Label>
            <Input id="edit-email" name="email" type="email" value={editingData.email} onChange={handleInputChange} className="col-span-3" disabled={isSaving} />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="edit-fullName" className="text-right">ชื่อ-นามสกุล</Label>
            <Input id="edit-fullName" name="fullName" value={editingData.fullName || ''} onChange={handleInputChange} className="col-span-3" disabled={isSaving} />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="edit-phoneNumber" className="text-right">เบอร์โทร</Label>
            <Input id="edit-phoneNumber" name="phoneNumber" value={editingData.phoneNumber || ''} onChange={handleInputChange} className="col-span-3" disabled={isSaving} />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="edit-balance" className="text-right">ยอดเงิน</Label>
            <Input id="edit-balance" name="balance" type="number" value={editingData.balance} onChange={handleBalanceChange} className="col-span-3" disabled={isSaving} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSaving}>ยกเลิก</Button>
          <Button type="submit" onClick={handleSaveChanges} disabled={isSaving}>
            {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} บันทึก
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditUserDialog;
