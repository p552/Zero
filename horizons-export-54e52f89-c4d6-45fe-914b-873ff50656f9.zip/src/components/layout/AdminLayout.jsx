
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import AdminHeader from '@/components/layout/AdminHeader';
import { motion } from 'framer-motion';

const AdminLayout = ({ children }) => {
  const { currentAdmin, loading } = useAdminAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!currentAdmin) {
    return <Navigate to="/admin_login" replace />;
  }

  return (
    <div className="flex min-h-screen flex-col">
      <AdminHeader />
      <motion.main 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="flex-1"
      >
        {children}
      </motion.main>
    </div>
  );
};

export default AdminLayout;
