
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Gamepad2 } from 'lucide-react';

const navLinks = [
  { name: 'หน้าแรก', path: '/', icon: <Home className="h-5 w-5 mr-2" /> },
  { name: 'เกม', path: '/games', icon: <Gamepad2 className="h-5 w-5 mr-2" /> },
];

const DesktopNav = () => {
  const location = useLocation();

  return (
    <div className="hidden md:flex items-center space-x-6">
      {navLinks.map((link) => (
        <Link
          key={link.path}
          to={link.path}
          className={`flex items-center text-sm font-medium transition-colors hover:text-primary ${
            location.pathname === link.path ? 'text-primary' : 'text-foreground/80'
          }`}
        >
          {link.icon}
          {link.name}
        </Link>
      ))}
    </div>
  );
};

export default DesktopNav;
