
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Home, Gamepad2, User, LogOut, CreditCard, LogIn } from 'lucide-react';

const navLinks = [
  { name: 'หน้าแรก', path: '/', icon: <Home className="h-5 w-5 mr-2" /> },
  { name: 'เกม', path: '/games', icon: <Gamepad2 className="h-5 w-5 mr-2" /> },
];

const MobileMenu = () => {
  const { currentUser, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.3 }}
      className="md:hidden bg-background/95 backdrop-blur-md border-t"
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col space-y-4">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`flex items-center p-2 rounded-md ${
                location.pathname === link.path
                  ? 'bg-primary/10 text-primary'
                  : 'text-foreground hover:bg-accent'
              }`}
            >
              {link.icon}
              {link.name}
            </Link>
          ))}

          {currentUser ? (
            <>
              <div className="p-2 rounded-md bg-muted/50">
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src={currentUser.avatarUrl} />
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {currentUser.username?.charAt(0).toUpperCase() || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{currentUser.username}</p>
                    <p className="text-sm text-muted-foreground">
                      {currentUser.balance?.toLocaleString() || 0} บาท
                    </p>
                  </div>
                </div>
              </div>

              <Link
                to="/profile"
                className="flex items-center p-2 rounded-md text-foreground hover:bg-accent"
              >
                <User className="h-5 w-5 mr-2" />
                โปรไฟล์
              </Link>

              <Link
                to="/deposit"
                className="flex items-center p-2 rounded-md text-foreground hover:bg-accent"
              >
                <CreditCard className="h-5 w-5 mr-2" />
                ฝากเงิน
              </Link>

              <Link
                to="/withdraw"
                className="flex items-center p-2 rounded-md text-foreground hover:bg-accent"
              >
                <CreditCard className="h-5 w-5 mr-2" />
                ถอนเงิน
              </Link>

              <button
                onClick={handleLogout}
                className="flex items-center p-2 rounded-md text-foreground hover:bg-accent w-full text-left"
              >
                <LogOut className="h-5 w-5 mr-2" />
                ออกจากระบบ
              </button>
            </>
          ) : (
            <div className="flex flex-col space-y-2">
              <Button onClick={() => navigate('/login')} className="w-full justify-start">
                <LogIn className="mr-2 h-4 w-4" />
                เข้าสู่ระบบ
              </Button>
              <Button onClick={() => navigate('/register')} variant="secondary" className="w-full justify-start">
                สมัครสมาชิก
              </Button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default MobileMenu;
