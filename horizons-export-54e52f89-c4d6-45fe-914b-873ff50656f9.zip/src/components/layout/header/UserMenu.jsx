
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { User, LogOut, CreditCard, LogIn } from 'lucide-react';

const UserMenu = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="hidden md:flex items-center space-x-4">
      {currentUser ? (
        <div className="flex items-center">
          <div className="mr-4 text-sm text-right">
            <span className="block text-muted-foreground text-xs">ยอดเงิน</span>
            <span className="font-bold text-primary">{currentUser.balance?.toLocaleString() || 0} บาท</span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                <Avatar>
                  <AvatarImage src={currentUser.avatarUrl} />
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {currentUser.username?.charAt(0).toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>บัญชีของฉัน</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate('/profile')}>
                <User className="mr-2 h-4 w-4" />
                <span>โปรไฟล์</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/deposit')}>
                <CreditCard className="mr-2 h-4 w-4" />
                <span>ฝากเงิน</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/withdraw')}>
                <CreditCard className="mr-2 h-4 w-4" />
                <span>ถอนเงิน</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>ออกจากระบบ</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ) : (
        <div className="flex items-center space-x-2">
          <Button variant="ghost" onClick={() => navigate('/login')}>
            <LogIn className="mr-2 h-4 w-4" />
            เข้าสู่ระบบ
          </Button>
          <Button onClick={() => navigate('/register')}>สมัครสมาชิก</Button>
        </div>
      )}
    </div>
  );
};

export default UserMenu;
