
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const HeaderLogo = () => {
  return (
    <Link to="/" className="flex items-center">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 3h16a2 2 0 0 1 2 2v6a10 10 0 0 1-10 10A10 10 0 0 1 2 11V5a2 2 0 0 1 2-2z"></path>
            <path d="M8 10V8l4 4 4-4v2"></path>
            <path d="M15 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
            <path d="M9 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
          </svg>
          <span className="text-xl font-bold">Placemakerbet</span>
        </div>
      </motion.div>
    </Link>
  );
};

export default HeaderLogo;
