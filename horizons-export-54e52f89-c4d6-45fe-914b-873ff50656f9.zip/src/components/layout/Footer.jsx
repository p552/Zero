
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, CreditCard, Shield } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-background border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 3h16a2 2 0 0 1 2 2v6a10 10 0 0 1-10 10A10 10 0 0 1 2 11V5a2 2 0 0 1 2-2z"></path>
                  <path d="M8 10V8l4 4 4-4v2"></path>
                  <path d="M15 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
                  <path d="M9 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
                </svg>
                <span className="text-xl font-bold">Placemakerbet</span>
              </div>
              <p className="text-muted-foreground mb-4">
                เว็บเกมออนไลน์ที่ดีที่สุด ฝาก-ถอนรวดเร็ว ปลอดภัย 100% บริการตลอด 24 ชั่วโมง
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <Facebook size={20} />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <Instagram size={20} />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <Twitter size={20} />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <Youtube size={20} />
                </a>
              </div>
            </motion.div>
          </div>

          {/* Quick Links */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <h3 className="text-lg font-semibold mb-4">ลิงก์ด่วน</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/" className="text-muted-foreground hover:text-primary transition-colors">
                    หน้าแรก
                  </Link>
                </li>
                <li>
                  <Link to="/games" className="text-muted-foreground hover:text-primary transition-colors">
                    เกมทั้งหมด
                  </Link>
                </li>
                <li>
                  <Link to="/deposit" className="text-muted-foreground hover:text-primary transition-colors">
                    ฝากเงิน
                  </Link>
                </li>
                <li>
                  <Link to="/withdraw" className="text-muted-foreground hover:text-primary transition-colors">
                    ถอนเงิน
                  </Link>
                </li>
                <li>
                  <Link to="/profile" className="text-muted-foreground hover:text-primary transition-colors">
                    โปรไฟล์
                  </Link>
                </li>
              </ul>
            </motion.div>
          </div>

          {/* Contact */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h3 className="text-lg font-semibold mb-4">ติดต่อเรา</h3>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <Mail className="h-5 w-5 mr-2 text-primary" />
                  <span className="text-muted-foreground">support@placemakerbet.com</span>
                </li>
                <li className="flex items-center">
                  <Phone className="h-5 w-5 mr-2 text-primary" />
                  <span className="text-muted-foreground">02-123-4567</span>
                </li>
              </ul>
            </motion.div>
          </div>

          {/* Security */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              viewport={{ once: true }}
            >
              <h3 className="text-lg font-semibold mb-4">ความปลอดภัย</h3>
              <div className="flex flex-col space-y-3">
                <div className="flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-primary" />
                  <span className="text-muted-foreground">การเข้ารหัส SSL 256-bit</span>
                </div>
                <div className="flex items-center">
                  <CreditCard className="h-5 w-5 mr-2 text-primary" />
                  <span className="text-muted-foreground">ระบบฝาก-ถอนอัตโนมัติ</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Placemakerbet. สงวนลิขสิทธิ์ทั้งหมด.</p>
          <p className="mt-2">
            เว็บไซต์นี้มีไว้สำหรับผู้ที่มีอายุ 18 ปีขึ้นไปเท่านั้น โปรดเล่นอย่างมีความรับผิดชอบ
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
