
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

const NotFoundPage = () => {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center text-center min-h-[calc(100vh-128px)]"> {/* Adjust min-height based on header/footer */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          <AlertTriangle className="h-24 w-24 text-primary mx-auto" />
          <h1 className="text-6xl font-bold">404</h1>
          <h2 className="text-2xl font-semibold">ไม่พบหน้าที่คุณต้องการ</h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            ขออภัย ดูเหมือนว่าหน้าที่คุณกำลังค้นหาไม่มีอยู่ หรืออาจถูกย้ายไปที่อื่นแล้ว
          </p>
          <Button asChild size="lg">
            <Link to="/">กลับสู่หน้าแรก</Link>
          </Button>
        </motion.div>
      </div>
    </MainLayout>
  );
};

export default NotFoundPage;
