
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import MainLayout from '@/components/layout/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, User, Mail, Phone, Edit, Save, X } from 'lucide-react';

const ProfilePage = () => {
  const { currentUser, updateProfile, loading, getTransactions } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    phoneNumber: '',
  });
  const [formErrors, setFormErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);

  React.useEffect(() => {
    if (!loading && !currentUser) {
      navigate('/login');
    } else if (currentUser) {
      setFormData({
        email: currentUser.email || '',
        fullName: currentUser.fullName || '',
        phoneNumber: currentUser.phoneNumber || '',
      });
    }
  }, [currentUser, loading, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.email.trim()) {
      errors.email = 'กรุณากรอกอีเมล';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'รูปแบบอีเมลไม่ถูกต้อง';
    }
    if (!formData.fullName.trim()) {
      errors.fullName = 'กรุณากรอกชื่อ-นามสกุล';
    }
    if (!formData.phoneNumber.trim()) {
      errors.phoneNumber = 'กรุณากรอกเบอร์โทรศัพท์';
    } else if (!/^\d{10}$/.test(formData.phoneNumber)) {
      errors.phoneNumber = 'เบอร์โทรศัพท์ต้องเป็นตัวเลข 10 หลัก';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSaveProfile = async () => {
    if (!validateForm()) return;

    setIsSaving(true);
    try {
      await updateProfile(formData);
      setIsEditing(false);
      toast({ title: "บันทึกข้อมูลสำเร็จ" });
    } catch (error) {
       // Error toast is handled in updateProfile hook
       console.error("Profile update failed:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const transactions = getTransactions();

  if (loading || !currentUser) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16 flex justify-center items-center min-h-[calc(100vh-64px)]">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="max-w-3xl mx-auto border-2">
            <CardHeader className="text-center">
              <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-primary">
                <AvatarImage src={currentUser.avatarUrl} />
                <AvatarFallback className="text-4xl bg-primary/20 text-primary">
                  {currentUser.username?.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <CardTitle className="text-3xl">{currentUser.username}</CardTitle>
              <CardDescription>จัดการข้อมูลส่วนตัวและดูประวัติการทำรายการ</CardDescription>
              <div className="mt-4">
                <span className="text-sm font-semibold">ยอดเงินคงเหลือ:</span>{' '}
                <span className="text-xl font-bold text-primary">฿{currentUser.balance.toLocaleString()}</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <Separator />
              
              <div>
                <div className="flex justify-between items-center mb-4">
                   <h3 className="text-xl font-semibold">ข้อมูลส่วนตัว</h3>
                   <Button variant="ghost" size="icon" onClick={() => setIsEditing(!isEditing)} disabled={isSaving}>
                     {isEditing ? <X className="h-5 w-5" /> : <Edit className="h-5 w-5" />}
                   </Button>
                </div>

                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="fullName">ชื่อ-นามสกุล</Label>
                      <Input id="fullName" name="fullName" value={formData.fullName} onChange={handleInputChange} disabled={isSaving}/>
                      {formErrors.fullName && <p className="text-sm text-destructive mt-1">{formErrors.fullName}</p>}
                    </div>
                    <div>
                      <Label htmlFor="email">อีเมล</Label>
                      <Input id="email" name="email" type="email" value={formData.email} onChange={handleInputChange} disabled={isSaving}/>
                       {formErrors.email && <p className="text-sm text-destructive mt-1">{formErrors.email}</p>}
                    </div>
                    <div>
                      <Label htmlFor="phoneNumber">เบอร์โทรศัพท์</Label>
                      <Input id="phoneNumber" name="phoneNumber" value={formData.phoneNumber} onChange={handleInputChange} disabled={isSaving}/>
                       {formErrors.phoneNumber && <p className="text-sm text-destructive mt-1">{formErrors.phoneNumber}</p>}
                    </div>
                    <Button onClick={handleSaveProfile} disabled={isSaving} className="w-full">
                      {isSaving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                      บันทึก
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <User className="h-5 w-5 mr-3 text-muted-foreground" />
                      <span>{formData.fullName || '-'}</span>
                    </div>
                    <div className="flex items-center">
                      <Mail className="h-5 w-5 mr-3 text-muted-foreground" />
                      <span>{formData.email || '-'}</span>
                    </div>
                    <div className="flex items-center">
                      <Phone className="h-5 w-5 mr-3 text-muted-foreground" />
                      <span>{formData.phoneNumber || '-'}</span>
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              <div>
                <h3 className="text-xl font-semibold mb-4">ประวัติการทำรายการล่าสุด</h3>
                {transactions.length === 0 ? (
                  <p className="text-muted-foreground text-center">ยังไม่มีรายการ</p>
                ) : (
                  <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                    {transactions.slice(0, 5).map((tx) => (
                       <div key={tx.id} className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                         <div>
                           <span className={`font-medium capitalize ${tx.type === 'deposit' || (tx.type === 'game' && tx.result === 'win') ? 'text-green-500' : tx.type === 'withdraw' || (tx.type === 'game' && tx.result === 'lose') ? 'text-red-500' : ''}`}>
                             {tx.type === 'deposit' ? 'ฝากเงิน' : tx.type === 'withdraw' ? 'ถอนเงิน' : `เกม: ${tx.gameName}`}
                           </span>
                           <p className="text-xs text-muted-foreground">
                             {new Date(tx.timestamp).toLocaleString('th-TH')}
                           </p>
                         </div>
                         <span className={`font-bold ${tx.type === 'deposit' || (tx.type === 'game' && tx.result === 'win') ? 'text-green-500' : tx.type === 'withdraw' || (tx.type === 'game' && tx.result === 'lose') ? 'text-red-500' : ''}`}>
                            {tx.type === 'deposit' ? `+฿${tx.amount.toLocaleString()}` :
                             tx.type === 'withdraw' ? `-฿${tx.amount.toLocaleString()}` :
                             tx.result === 'win' ? `+฿${tx.winAmount.toLocaleString()}` : `-฿${tx.betAmount.toLocaleString()}`}
                         </span>
                       </div>
                    ))}
                  </div>
                )}
                {transactions.length > 5 && (
                    <Button variant="link" className="mt-2" onClick={() => navigate('/transactions')}>ดูทั้งหมด</Button> 
                    // Assuming a /transactions route will be created
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </MainLayout>
  );
};

export default ProfilePage;
