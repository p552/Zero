
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import MainLayout from '@/components/layout/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, ArrowLeft } from 'lucide-react';

const WithdrawPage = () => {
  const { currentUser, withdraw, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [amount, setAmount] = useState('');
  const [bankAccount, setBankAccount] = useState(''); // Example: Could be pre-filled or selected
  const [accountName, setAccountName] = useState(''); // Example: Could be pre-filled
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [errors, setErrors] = useState({});

  React.useEffect(() => {
    if (!loading && !currentUser) {
      navigate('/login');
    } else if (currentUser) {
       // Pre-fill if possible, otherwise leave empty
       setAccountName(currentUser.fullName || ''); 
       // Bank account might need separate management/input
    }
  }, [currentUser, loading, navigate]);

  const handleAmountChange = (e) => {
    const value = e.target.value;
     if (/^\d*$/.test(value)) {
      setAmount(value);
    }
  };

   const validateForm = () => {
    const newErrors = {};
    const numAmount = parseInt(amount);
    
    if (!amount || isNaN(numAmount) || numAmount <= 0) {
      newErrors.amount = 'กรุณากรอกจำนวนเงินที่ถูกต้อง (มากกว่า 0)';
    } else if (currentUser && numAmount > currentUser.balance) {
      newErrors.amount = 'ยอดเงินในบัญชีไม่เพียงพอ';
    }
    if (!bankAccount.trim()) {
      newErrors.bankAccount = 'กรุณากรอกเลขที่บัญชีธนาคาร';
    } else if (!/^\d+$/.test(bankAccount.replace(/-/g, ''))) {
       newErrors.bankAccount = 'เลขที่บัญชีต้องเป็นตัวเลขเท่านั้น';
    }
     if (!accountName.trim()) {
      newErrors.accountName = 'กรุณากรอกชื่อบัญชี';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };


  const handleWithdraw = async () => {
     if (!validateForm()) return;

    setIsWithdrawing(true);
    const numAmount = parseInt(amount);

    try {
      await withdraw(numAmount, bankAccount, accountName);
      // Toast is handled within the withdraw function
      navigate('/profile'); // Redirect to profile after request
    } catch (error) {
      // Error toast is handled within the withdraw function
      console.error("Withdrawal failed:", error);
    } finally {
      setIsWithdrawing(false);
    }
  };

   if (loading || !currentUser) {
     return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16 flex justify-center items-center min-h-[calc(100vh-64px)]">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }


  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-16">
         <Button
          variant="ghost"
          onClick={() => navigate(-1)} // Go back
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          กลับ
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="max-w-md mx-auto border-2">
            <CardHeader>
              <CardTitle className="text-2xl font-bold">ถอนเงิน</CardTitle>
              <CardDescription>กรอกข้อมูลเพื่อส่งคำขอถอนเงิน</CardDescription>
               <div className="mt-2 text-sm">
                 ยอดเงินที่ถอนได้: <span className="font-bold text-primary">฿{currentUser.balance.toLocaleString()}</span>
               </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="amount">จำนวนเงิน (บาท)</Label>
                <Input 
                  id="amount" 
                  type="number" 
                  placeholder="ระบุจำนวนเงินที่ต้องการถอน" 
                  value={amount} 
                  onChange={handleAmountChange}
                  disabled={isWithdrawing}
                  min="1"
                  max={currentUser.balance}
                />
                 {errors.amount && <p className="text-sm text-destructive mt-1">{errors.amount}</p>}
              </div>
              <div>
                 <Label htmlFor="bankAccount">เลขที่บัญชีธนาคาร</Label>
                 <Input 
                   id="bankAccount" 
                   placeholder="กรอกเลขที่บัญชี" 
                   value={bankAccount} 
                   onChange={(e) => setBankAccount(e.target.value)}
                   disabled={isWithdrawing}
                 />
                  {errors.bankAccount && <p className="text-sm text-destructive mt-1">{errors.bankAccount}</p>}
              </div>
               <div>
                 <Label htmlFor="accountName">ชื่อบัญชี</Label>
                 <Input 
                   id="accountName" 
                   placeholder="กรอกชื่อบัญชีให้ตรงกับหน้าสมุด" 
                   value={accountName} 
                   onChange={(e) => setAccountName(e.target.value)}
                   disabled={isWithdrawing}
                 />
                  {errors.accountName && <p className="text-sm text-destructive mt-1">{errors.accountName}</p>}
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button 
                onClick={handleWithdraw} 
                className="w-full" 
                disabled={isWithdrawing || !amount || !bankAccount || !accountName || (currentUser && parseInt(amount) > currentUser.balance)}
              >
                {isWithdrawing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    กำลังส่งคำขอ...
                  </>
                ) : (
                  'ยืนยันการถอนเงิน'
                )}
              </Button>
               <p className="text-xs text-muted-foreground text-center pt-2">
                  การถอนเงินอาจใช้เวลาดำเนินการ โปรดรอการตรวจสอบจากเจ้าหน้าที่
               </p>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    </MainLayout>
  );
};

export default WithdrawPage;
