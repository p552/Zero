
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Search } from 'lucide-react';

const GamesPage = () => {
  const navigate = useNavigate();
  const [games, setGames] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [filteredGames, setFilteredGames] = useState([]);

  useEffect(() => {
    // Get games from localStorage
    const storedGames = JSON.parse(localStorage.getItem('richyGameGames') || '[]');
    setGames(storedGames);
    setFilteredGames(storedGames);
  }, []);

  useEffect(() => {
    // Filter games based on search term and active category
    let filtered = games;
    
    if (searchTerm) {
      filtered = filtered.filter(game => 
        game.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        game.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (activeCategory !== 'all') {
      filtered = filtered.filter(game => game.category === activeCategory);
    }
    
    setFilteredGames(filtered);
  }, [searchTerm, activeCategory, games]);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleCategoryChange = (value) => {
    setActiveCategory(value);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold mb-4">เกมทั้งหมด</h1>
          <p className="text-muted-foreground">
            เลือกเกมที่คุณชื่นชอบและเริ่มเล่นได้ทันที
          </p>
        </motion.div>

        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="ค้นหาเกม..."
                value={searchTerm}
                onChange={handleSearch}
                className="pl-10"
              />
            </div>
          </div>

          <Tabs defaultValue="all" onValueChange={handleCategoryChange}>
            <TabsList className="mb-6">
              <TabsTrigger value="all">ทั้งหมด</TabsTrigger>
              <TabsTrigger value="slots">สล็อต</TabsTrigger>
              <TabsTrigger value="card">ไพ่</TabsTrigger>
              <TabsTrigger value="table">เกมโต๊ะ</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-0">
              <GameGrid games={filteredGames} navigate={navigate} />
            </TabsContent>
            
            <TabsContent value="slots" className="mt-0">
              <GameGrid games={filteredGames} navigate={navigate} />
            </TabsContent>
            
            <TabsContent value="card" className="mt-0">
              <GameGrid games={filteredGames} navigate={navigate} />
            </TabsContent>
            
            <TabsContent value="table" className="mt-0">
              <GameGrid games={filteredGames} navigate={navigate} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
};

const GameGrid = ({ games, navigate }) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  if (games.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">ไม่พบเกมที่ค้นหา</p>
      </div>
    );
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
    >
      {games.map((game) => (
        <motion.div key={game.id} variants={itemVariants} className="game-card">
          <Card className="overflow-hidden h-full border-2 hover:border-primary transition-all duration-300">
            <div className="relative aspect-[4/3] w-full overflow-hidden">
              <img  alt={game.name} className="w-full h-full object-cover transition-transform duration-300 hover:scale-110" src="https://images.unsplash.com/photo-1629919683003-03b71a6a1758" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-4">
                <h3 className="text-lg font-bold text-white">{game.name}</h3>
                <p className="text-sm text-gray-200">{game.description}</p>
              </div>
            </div>
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div className="text-sm text-muted-foreground">
                  เดิมพัน ฿{game.minBet} - ฿{game.maxBet}
                </div>
                <Button size="sm" onClick={() => navigate(`/games/${game.id}`)}>
                  เล่นเลย
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default GamesPage;
