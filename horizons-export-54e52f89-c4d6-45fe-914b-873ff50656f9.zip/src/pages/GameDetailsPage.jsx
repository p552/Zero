
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import MainLayout from '@/components/layout/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, Gamepad2, DollarSign, Trophy } from 'lucide-react';

const GameDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser, updateBalance } = useAuth(); // Assuming updateBalance is exposed by context after refactor
  const { toast } = useToast();
  
  const [game, setGame] = useState(null);
  const [loading, setLoading] = useState(true);
  const [betAmount, setBetAmount] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameResult, setGameResult] = useState(null);

  useEffect(() => {
    const games = JSON.parse(localStorage.getItem('richyGameGames') || '[]');
    const foundGame = games.find(g => g.id === id);
    
    if (foundGame) {
      setGame(foundGame);
      // Set default bet amount to min bet or clear it
      // setBetAmount(String(foundGame.minBet)); 
      setBetAmount(''); 
    } else {
      toast({
        variant: "destructive",
        title: "ไม่พบเกม",
        description: "ไม่พบเกมที่คุณต้องการ",
      });
      navigate('/games');
    }
    
    setLoading(false);
  }, [id, navigate, toast]);

  const handleBetChange = (e) => {
    const value = e.target.value;
    // Allow only numbers
    if (/^\d*$/.test(value)) {
      setBetAmount(value);
    }
  };

  const handlePlay = () => {
    if (!currentUser) {
      toast({
        variant: "destructive",
        title: "กรุณาเข้าสู่ระบบ",
        description: "คุณต้องเข้าสู่ระบบก่อนเล่นเกม",
      });
      navigate('/login');
      return;
    }
    
    const bet = parseInt(betAmount);
    
    if (!betAmount || isNaN(bet) || bet <= 0) {
      toast({
        variant: "destructive",
        title: "จำนวนเงินไม่ถูกต้อง",
        description: "กรุณาระบุจำนวนเงินเดิมพันที่มากกว่า 0",
      });
      return;
    }
    
    if (bet < game.minBet) {
      toast({
        variant: "destructive",
        title: "จำนวนเงินน้อยเกินไป",
        description: `จำนวนเงินเดิมพันขั้นต่ำคือ ฿${game.minBet}`,
      });
      return;
    }
    
    if (bet > game.maxBet) {
      toast({
        variant: "destructive",
        title: "จำนวนเงินมากเกินไป",
        description: `จำนวนเงินเดิมพันสูงสุดคือ ฿${game.maxBet}`,
      });
      return;
    }
    
    if (bet > currentUser.balance) {
      toast({
        variant: "destructive",
        title: "ยอดเงินไม่เพียงพอ",
        description: "กรุณาฝากเงินเพิ่มเพื่อเล่นเกม",
      });
      return;
    }
    
    setIsPlaying(true);
    setGameResult(null); // Clear previous result
    
    // Simulate game result after 1.5 seconds
    setTimeout(() => {
      const isWin = Math.random() < 0.4; // 40% chance to win
      const winMultiplier = 2; // Example: win pays 2x the bet
      const amountChange = isWin ? bet * (winMultiplier - 1) : -bet;
      const finalWinAmount = isWin ? bet * winMultiplier : 0;

      // Update balance using the context function
      updateBalance(amountChange, {
        type: 'game',
        gameId: game.id,
        gameName: game.name,
        betAmount: bet,
        winAmount: finalWinAmount,
        result: isWin ? 'win' : 'lose',
      })
      .then(() => {
          setGameResult({
            isWin,
            betAmount: bet,
            winAmount: finalWinAmount
          });

          toast({
            title: isWin ? "ยินดีด้วย! คุณชนะ" : "เสียใจด้วย! คุณแพ้",
            description: isWin 
              ? `คุณได้รับเงิน ฿${finalWinAmount.toLocaleString()}`
              : `คุณเสียเงิน ฿${bet.toLocaleString()}`,
            variant: isWin ? "default" : "destructive",
          });
      })
      .catch(error => {
          toast({
            variant: "destructive",
            title: "เกิดข้อผิดพลาดในการบันทึกผล",
            description: error.message || "ไม่สามารถอัปเดตยอดเงินได้",
          });
      })
      .finally(() => {
          setIsPlaying(false);
      });

    }, 1500);
  };

  const handlePlayAgain = () => {
    setGameResult(null);
    setBetAmount(''); // Reset bet amount
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16 flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </MainLayout>
    );
  }

  if (!game) {
    // This case should ideally not happen due to the check in useEffect, but good practice to keep it.
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16 flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">ไม่พบเกม</h2>
            <Button onClick={() => navigate('/games')}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              กลับไปหน้าเกม
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-16">
        <Button
          variant="ghost"
          onClick={() => navigate('/games')}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          กลับไปหน้าเกม
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Game Image/Placeholder */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-2"
          >
            <div className="relative aspect-video rounded-lg overflow-hidden bg-muted border flex items-center justify-center">
               {/* Replace with actual game canvas/iframe later */}
              <Gamepad2 className="h-24 w-24 text-muted-foreground opacity-50" /> 
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-6">
                <h1 className="text-3xl font-bold text-white">{game.name}</h1>
                <p className="text-gray-200 mt-2">{game.description}</p>
              </div>
            </div>
          </motion.div>

          {/* Game Controls */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-card rounded-lg border-2 p-6 flex flex-col"
          >
            <div className="flex-1">
              {gameResult ? (
                <div className="text-center flex flex-col justify-center items-center h-full">
                  <motion.div
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 260, damping: 20 }}
                  >
                    <div className={`mb-4 ${gameResult.isWin ? 'text-green-500' : 'text-red-500'}`}>
                      {gameResult.isWin ? (
                        <Trophy className="h-16 w-16 mx-auto" />
                      ) : (
                        <DollarSign className="h-16 w-16 mx-auto" /> 
                      )}
                    </div>
                    <h2 className="text-2xl font-bold mb-2">
                      {gameResult.isWin ? 'คุณชนะ!' : 'คุณแพ้!'}
                    </h2>
                    <div className="mb-6">
                      <p className="text-muted-foreground">เดิมพัน: ฿{gameResult.betAmount.toLocaleString()}</p>
                      {gameResult.isWin && (
                        <p className="text-green-500 font-bold">
                          ได้รับเงิน: ฿{gameResult.winAmount.toLocaleString()}
                        </p>
                      )}
                    </div>
                  </motion.div>
                </div>
              ) : (
                <>
                  <h2 className="text-xl font-bold mb-4">เริ่มเล่นเกม</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-baseline mb-2">
                        <Label htmlFor="betAmount">จำนวนเงินเดิมพัน</Label>
                        <span className="text-xs text-muted-foreground">
                          (฿{game.minBet} - ฿{game.maxBet})
                        </span>
                      </div>
                      <div className="relative">
                        <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                        <Input
                          id="betAmount"
                          placeholder="ระบุจำนวนเงิน"
                          value={betAmount}
                          onChange={handleBetChange}
                          className="pl-10 text-lg h-12"
                          disabled={isPlaying}
                          type="number"
                          min={game.minBet}
                          max={game.maxBet}
                          step="1"
                        />
                      </div>
                       {currentUser && (
                         <p className="text-xs text-muted-foreground mt-1 text-right">
                          ยอดเงินคงเหลือ: ฿{currentUser.balance?.toLocaleString() || 0}
                         </p>
                       )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Action Button Area */}
            <div className="mt-6">
              {gameResult ? (
                 <Button onClick={handlePlayAgain} className="w-full text-lg py-6">เล่นอีกครั้ง</Button>
              ) : (
                <>
                  <Button 
                    onClick={handlePlay} 
                    className="w-full text-lg py-6" 
                    disabled={isPlaying || !betAmount || parseInt(betAmount) <= 0 || (currentUser && parseInt(betAmount) > currentUser.balance)}
                  >
                    {isPlaying ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-2"></div>
                        กำลังเล่น...
                      </div>
                    ) : (
                      <>
                        <Gamepad2 className="mr-2 h-5 w-5" />
                        เล่นเลย
                      </>
                    )}
                  </Button>
                    
                  {!currentUser && (
                    <div className="text-center mt-4">
                      <p className="text-sm text-muted-foreground mb-2">
                        กรุณาเข้าสู่ระบบเพื่อเล่นเกม
                      </p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => navigate('/login')}
                      >
                        เข้าสู่ระบบ
                      </Button>
                    </div>
                  )}
                </>
              )}
            </div>
          </motion.div>
        </div>

        {/* Game Details Section */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-card rounded-lg border p-6"
          >
            <h3 className="text-lg font-semibold mb-4">รายละเอียดเกม</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">ประเภท:</span>
                <span className="font-medium capitalize">{game.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">เดิมพันขั้นต่ำ:</span>
                <span className="font-medium">฿{game.minBet.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">เดิมพันสูงสุด:</span>
                <span className="font-medium">฿{game.maxBet.toLocaleString()}</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
             className="bg-card rounded-lg border p-6"
          >
             <h3 className="text-lg font-semibold mb-4">วิธีการเล่น</h3>
             <p className="text-sm text-muted-foreground">
               {/* Add specific game rules here if available, otherwise keep generic */}
               วางเดิมพันของคุณแล้วกดปุ่ม "เล่นเลย" เพื่อเริ่มเกม ขอให้โชคดี!
             </p>
          </motion.div>

           <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
             className="bg-card rounded-lg border p-6"
          >
             <h3 className="text-lg font-semibold mb-4">ความนิยม</h3>
             <div className="flex items-center">
               <Trophy className="h-5 w-5 text-yellow-500 mr-2"/>
               <span className="font-medium">{game.popularity}%</span> 
             </div>
              <p className="text-sm text-muted-foreground mt-1">
                 {game.popularity > 90 ? "เกมยอดฮิต!" : game.popularity > 75 ? "เป็นที่นิยม" : "น่าสนใจ"}
               </p>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  );
};

export default GameDetailsPage;
