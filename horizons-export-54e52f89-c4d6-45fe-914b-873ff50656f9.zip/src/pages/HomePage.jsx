
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowRight, Trophy, Shield, CreditCard, Zap } from 'lucide-react';

const HomePage = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [jackpot, setJackpot] = useState(1000000);
  const [popularGames, setPopularGames] = useState([]);

  useEffect(() => {
    // Simulate jackpot increasing
    const interval = setInterval(() => {
      setJackpot(prev => prev + Math.floor(Math.random() * 100));
    }, 5000);

    // Get popular games from localStorage
    const games = JSON.parse(localStorage.getItem('richyGameGames') || '[]');
    const sortedGames = [...games].sort((a, b) => b.popularity - a.popularity).slice(0, 4);
    setPopularGames(sortedGames);

    return () => clearInterval(interval);
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent z-10"></div>
        <div className="absolute inset-0 overflow-hidden">
          <img  alt="Casino gaming background" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1629919683003-03b71a6a1758" />
        </div>
        <div className="container mx-auto px-4 py-24 md:py-32 relative z-20">
          <div className="max-w-2xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-4 text-white">
                ยินดีต้อนรับสู่ <span className="text-primary">Richy Game</span>
              </h1>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <p className="text-xl mb-8 text-gray-200">
                เว็บเกมออนไลน์ที่ดีที่สุด ฝาก-ถอนรวดเร็ว ปลอดภัย 100% พร้อมเกมให้เลือกเล่นมากมาย
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex flex-wrap gap-4"
            >
              {!currentUser ? (
                <>
                  <Button size="lg" onClick={() => navigate('/register')}>
                    สมัครสมาชิก
                  </Button>
                  <Button size="lg" variant="outline" onClick={() => navigate('/login')}>
                    เข้าสู่ระบบ
                  </Button>
                </>
              ) : (
                <>
                  <Button size="lg" onClick={() => navigate('/games')}>
                    เล่นเกมเลย
                  </Button>
                  <Button size="lg" variant="outline" onClick={() => navigate('/deposit')}>
                    ฝากเงิน
                  </Button>
                </>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Jackpot Counter */}
      <section className="bg-primary py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center justify-center">
            <h2 className="text-xl font-semibold text-primary-foreground mb-2">แจ็คพอตรวม</h2>
            <div className="jackpot-counter text-4xl md:text-5xl font-bold text-white">
              ฿{jackpot.toLocaleString()}
            </div>
          </div>
        </div>
      </section>

      {/* Popular Games */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">เกมยอดนิยม</h2>
            <Button variant="ghost" onClick={() => navigate('/games')}>
              ดูทั้งหมด <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {popularGames.map((game) => (
              <motion.div key={game.id} variants={itemVariants} className="game-card">
                <Card className="overflow-hidden h-full border-2 hover:border-primary transition-all duration-300">
                  <div className="relative aspect-[4/3] w-full overflow-hidden">
                    <img  alt={game.name} className="w-full h-full object-cover transition-transform duration-300 hover:scale-110" src="https://images.unsplash.com/photo-1629919683003-03b71a6a1758" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-4">
                      <h3 className="text-lg font-bold text-white">{game.name}</h3>
                      <p className="text-sm text-gray-200">{game.description}</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-muted-foreground">
                        เดิมพัน ฿{game.minBet} - ฿{game.maxBet}
                      </div>
                      <Button size="sm" onClick={() => navigate(`/games/${game.id}`)}>
                        เล่นเลย
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-2xl md:text-3xl font-bold mb-4">ทำไมต้องเลือก Richy Game</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              เรามุ่งมั่นที่จะมอบประสบการณ์การเล่นเกมที่ดีที่สุดให้กับผู้เล่นทุกคน
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="bg-background p-6 rounded-lg shadow-md border border-border"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">รวดเร็ว</h3>
              <p className="text-muted-foreground">
                ระบบฝาก-ถอนอัตโนมัติ รวดเร็วทันใจ ไม่ต้องรอนาน
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-background p-6 rounded-lg shadow-md border border-border"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">ปลอดภัย</h3>
              <p className="text-muted-foreground">
                ระบบความปลอดภัยมาตรฐานสากล ข้อมูลของคุณปลอดภัย 100%
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              viewport={{ once: true }}
              className="bg-background p-6 rounded-lg shadow-md border border-border"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Trophy className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">รางวัลใหญ่</h3>
              <p className="text-muted-foreground">
                โอกาสชนะรางวัลใหญ่ แจ็คพอตมูลค่าสูงรอคุณอยู่
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true }}
              className="bg-background p-6 rounded-lg shadow-md border border-border"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <CreditCard className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">หลากหลายช่องทาง</h3>
              <p className="text-muted-foreground">
                รองรับการชำระเงินหลากหลายช่องทาง สะดวกสบายสำหรับคุณ
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img  alt="Casino pattern background" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1629919683003-03b71a6a1758" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
                พร้อมที่จะเริ่มต้นความสนุกแล้วหรือยัง?
              </h2>
              <p className="text-xl mb-8 text-primary-foreground/90">
                สมัครสมาชิกวันนี้ รับโบนัสต้อนรับ 100% สูงสุด 1,000 บาท
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                {!currentUser ? (
                  <Button
                    size="lg"
                    variant="secondary"
                    className="bg-white text-primary hover:bg-white/90"
                    onClick={() => navigate('/register')}
                  >
                    สมัครสมาชิกเลย
                  </Button>
                ) : (
                  <Button
                    size="lg"
                    variant="secondary"
                    className="bg-white text-primary hover:bg-white/90"
                    onClick={() => navigate('/games')}
                  >
                    เล่นเกมเลย
                  </Button>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default HomePage;
