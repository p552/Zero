
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import MainLayout from '@/components/layout/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/components/ui/use-toast';
import { Loader2, ArrowLeft, Banknote, CreditCard as CreditCardIcon } from 'lucide-react'; // Renamed icon to avoid conflict

const DepositPage = () => {
  const { currentUser, deposit, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [isDepositing, setIsDepositing] = useState(false);
  const [errors, setErrors] = useState({});

  React.useEffect(() => {
    if (!loading && !currentUser) {
      navigate('/login');
    }
  }, [currentUser, loading, navigate]);

  const handleAmountChange = (e) => {
    const value = e.target.value;
    if (/^\d*$/.test(value)) { // Allow only numbers
      setAmount(value);
    }
  };

   const validateForm = () => {
    const newErrors = {};
    const numAmount = parseInt(amount);
    
    if (!amount || isNaN(numAmount) || numAmount <= 0) {
      newErrors.amount = 'กรุณากรอกจำนวนเงินที่ถูกต้อง (มากกว่า 0)';
    }
    if (!paymentMethod) {
      newErrors.paymentMethod = 'กรุณาเลือกช่องทางการฝากเงิน';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };


  const handleDeposit = async () => {
    if (!validateForm()) return;
    
    setIsDepositing(true);
    const numAmount = parseInt(amount);

    try {
      await deposit(numAmount, paymentMethod, { note: `ฝากผ่าน ${paymentMethod}` });
      // Toast is handled within the deposit function
      navigate('/profile'); // Redirect to profile after successful deposit
    } catch (error) {
      // Error toast is handled within the deposit function
      console.error("Deposit failed:", error);
    } finally {
      setIsDepositing(false);
    }
  };

  if (loading || !currentUser) {
     return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16 flex justify-center items-center min-h-[calc(100vh-64px)]">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }


  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-16">
         <Button
          variant="ghost"
          onClick={() => navigate(-1)} // Go back to previous page
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          กลับ
        </Button>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="max-w-md mx-auto border-2">
            <CardHeader>
              <CardTitle className="text-2xl font-bold">ฝากเงิน</CardTitle>
              <CardDescription>เลือกช่องทางและกรอกจำนวนเงินที่ต้องการฝาก</CardDescription>
               <div className="mt-2 text-sm">
                 ยอดเงินปัจจุบัน: <span className="font-bold text-primary">฿{currentUser.balance.toLocaleString()}</span>
               </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="amount">จำนวนเงิน (บาท)</Label>
                <Input 
                  id="amount" 
                  type="number" 
                  placeholder="ระบุจำนวนเงิน" 
                  value={amount} 
                  onChange={handleAmountChange}
                  disabled={isDepositing}
                  min="1"
                />
                {errors.amount && <p className="text-sm text-destructive mt-1">{errors.amount}</p>}
              </div>
              <div>
                 <Label htmlFor="paymentMethod">ช่องทางการฝาก</Label>
                 <Select onValueChange={setPaymentMethod} value={paymentMethod} disabled={isDepositing}>
                    <SelectTrigger id="paymentMethod">
                      <SelectValue placeholder="เลือกช่องทาง" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bank_transfer">
                        <div className="flex items-center">
                          <Banknote className="mr-2 h-4 w-4" /> โอนผ่านธนาคาร
                        </div>
                      </SelectItem>
                      <SelectItem value="qr_code">
                         <div className="flex items-center">
                           <CreditCardIcon className="mr-2 h-4 w-4" /> QR Code (PromptPay)
                         </div>
                      </SelectItem>
                       {/* Add more methods if needed */}
                    </SelectContent>
                  </Select>
                   {errors.paymentMethod && <p className="text-sm text-destructive mt-1">{errors.paymentMethod}</p>}
              </div>

              {/* Placeholder for payment instructions */}
              {paymentMethod === 'bank_transfer' && (
                <div className="bg-muted/50 p-3 rounded-md text-sm text-muted-foreground">
                  กรุณาโอนเงินมาที่: ธนาคาร Xyz, เลขที่บัญชี 123-456-7890, ชื่อบัญชี Richy Game Co. Ltd.
                  <br />
                  (นี่เป็นข้อมูลตัวอย่าง)
                </div>
              )}
               {paymentMethod === 'qr_code' && (
                <div className="bg-muted/50 p-3 rounded-md text-sm text-muted-foreground text-center">
                   <img  alt="QR Code Placeholder" className="mx-auto mb-2 w-32 h-32 bg-gray-300" src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=ExamplePromptPayData" />
                   สแกน QR Code นี้เพื่อชำระเงิน
                   <br />
                  (นี่เป็นข้อมูลตัวอย่าง)
                </div>
              )}


            </CardContent>
            <CardFooter>
              <Button onClick={handleDeposit} className="w-full" disabled={isDepositing || !amount || !paymentMethod}>
                {isDepositing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    กำลังดำเนินการ...
                  </>
                ) : (
                  'ยืนยันการฝากเงิน'
                )}
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    </MainLayout>
  );
};

export default DepositPage;
