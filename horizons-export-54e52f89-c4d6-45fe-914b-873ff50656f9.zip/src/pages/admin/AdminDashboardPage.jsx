
import React, { useState, useEffect } from 'react';
import AdminLayout from '@/components/layout/AdminLayout';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, CreditCard, Activity, TrendingUp, DollarSign, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

const AdminDashboardPage = () => {
  const { getSystemStats } = useAdminAuth();
  const [stats, setStats] = useState(null);
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    setLoadingStats(true);
    // Simulate fetching stats
    setTimeout(() => {
       try {
          const systemStats = getSystemStats();
          setStats(systemStats);
       } catch (error) {
          console.error("Failed to get system stats:", error);
          // Optionally set an error state
       } finally {
          setLoadingStats(false);
       }
    }, 500); // Short delay to simulate fetch
  }, [getSystemStats]);

   const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.4 }
    }
  };


  return (
    <AdminLayout>
      <div className="container mx-auto px-4 py-8">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-3xl font-bold mb-6"
        >
          แดชบอร์ด
        </motion.h1>

        {loadingStats ? (
          <div className="flex justify-center items-center h-64">
             <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : stats ? (
          <motion.div 
             variants={containerVariants}
             initial="hidden"
             animate="visible"
             className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <motion.div variants={itemVariants}>
               <Card className="admin-card border-l-4 border-primary">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">ผู้ใช้ทั้งหมด</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">+{stats.newUsersToday} ใหม่วันนี้</p>
                  </CardContent>
               </Card>
             </motion.div>
             
              <motion.div variants={itemVariants}>
                <Card className="admin-card border-l-4 border-green-500">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">ยอดฝากรวม</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">฿{stats.totalDeposits.toLocaleString()}</div>
                     <p className="text-xs text-muted-foreground">สถานะ: สำเร็จ</p>
                  </CardContent>
                </Card>
             </motion.div>

             <motion.div variants={itemVariants}>
                <Card className="admin-card border-l-4 border-red-500">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">ยอดถอนรวม</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground transform scale-y-[-1]" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">฿{stats.totalWithdrawals.toLocaleString()}</div>
                     <p className="text-xs text-muted-foreground">สถานะ: สำเร็จ</p>
                  </CardContent>
                </Card>
              </motion.div>
              
               <motion.div variants={itemVariants}>
                  <Card className="admin-card border-l-4 border-yellow-500">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">ยอดถอนรอดำเนินการ</CardTitle>
                      <Activity className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">฿{stats.pendingWithdrawals.toLocaleString()}</div>
                      <p className="text-xs text-muted-foreground">รายการที่ต้องตรวจสอบ</p>
                    </CardContent>
                  </Card>
               </motion.div>
               
                <motion.div variants={itemVariants}>
                  <Card className="admin-card border-l-4 border-blue-500">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">ยอดเงินในระบบทั้งหมด</CardTitle>
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">฿{stats.totalBalance.toLocaleString()}</div>
                      <p className="text-xs text-muted-foreground">ยอดรวมของผู้ใช้ทั้งหมด</p>
                    </CardContent>
                  </Card>
               </motion.div>

            {/* Add more stats cards as needed */}
          </motion.div>
        ) : (
           <div className="text-center py-12 text-muted-foreground">
             <p>ไม่สามารถโหลดข้อมูลสถิติได้</p>
           </div>
        )}
      </div>
    </AdminLayout>
  );
};

export default AdminDashboardPage;
