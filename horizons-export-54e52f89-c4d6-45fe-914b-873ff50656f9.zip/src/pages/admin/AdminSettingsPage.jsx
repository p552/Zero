
import React, { useState } from 'react';
import AdminLayout from '@/components/layout/AdminLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Loader2, Save } from 'lucide-react';

const AdminSettingsPage = () => {
  const { toast } = useToast();
  // Placeholder states - replace with actual settings logic (e.g., using localStorage or API)
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [maxWithdrawal, setMaxWithdrawal] = useState('10000');
  const [minDeposit, setMinDeposit] = useState('100');
  const [isLoading, setIsLoading] = useState(false);

  // Load settings on mount (Example using localStorage)
  React.useEffect(() => {
     const savedSettings = JSON.parse(localStorage.getItem('richyGameAdminSettings') || '{}');
     setMaintenanceMode(savedSettings.maintenanceMode || false);
     setMaxWithdrawal(savedSettings.maxWithdrawal || '10000');
     setMinDeposit(savedSettings.minDeposit || '100');
  }, []);


  const handleSaveSettings = () => {
    setIsLoading(true);
    // Basic validation
    const numMaxWithdrawal = parseInt(maxWithdrawal);
    const numMinDeposit = parseInt(minDeposit);

    if (isNaN(numMaxWithdrawal) || numMaxWithdrawal < 0 || isNaN(numMinDeposit) || numMinDeposit < 0) {
        toast({ variant: "destructive", title: "ข้อมูลไม่ถูกต้อง", description: "กรุณากรอกตัวเลขที่ถูกต้องสำหรับยอดฝาก/ถอน" });
        setIsLoading(false);
        return;
    }
    
    // Simulate saving settings (Example using localStorage)
    setTimeout(() => {
      try {
        const settingsToSave = {
            maintenanceMode,
            maxWithdrawal: String(numMaxWithdrawal), // Store as string
            minDeposit: String(numMinDeposit) // Store as string
        };
        localStorage.setItem('richyGameAdminSettings', JSON.stringify(settingsToSave));
        toast({ title: "บันทึกการตั้งค่าสำเร็จ" });
      } catch (error) {
         toast({ variant: "destructive", title: "บันทึกการตั้งค่าล้มเหลว", description: error.message });
      } finally {
        setIsLoading(false);
      }
    }, 500);
  };

  return (
    <AdminLayout>
      <div className="container mx-auto px-4 py-8">
        <motion.h1 
           initial={{ opacity: 0, y: -20 }}
           animate={{ opacity: 1, y: 0 }}
           className="text-3xl font-bold mb-6"
        >
          ตั้งค่าระบบ
        </motion.h1>

        <div className="grid gap-6 md:grid-cols-2">
           <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
             <Card>
               <CardHeader>
                 <CardTitle>การตั้งค่าทั่วไป</CardTitle>
                 <CardDescription>จัดการการตั้งค่าพื้นฐานของระบบ</CardDescription>
               </CardHeader>
               <CardContent className="space-y-4">
                  <div className="flex items-center justify-between space-x-2 p-4 border rounded-lg">
                    <Label htmlFor="maintenance-mode" className="flex flex-col space-y-1">
                       <span>โหมดปรับปรุงระบบ</span>
                       <span className="font-normal leading-snug text-muted-foreground">
                         เมื่อเปิดใช้งาน ผู้ใช้ทั่วไปจะไม่สามารถเข้าสู่ระบบหรือเล่นเกมได้
                       </span>
                     </Label>
                    <Switch
                      id="maintenance-mode"
                      checked={maintenanceMode}
                      onCheckedChange={setMaintenanceMode}
                      disabled={isLoading}
                    />
                  </div>
                  {/* Add more general settings here */}
               </CardContent>
             </Card>
           </motion.div>

           <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
             <Card>
               <CardHeader>
                 <CardTitle>การตั้งค่าการเงิน</CardTitle>
                 <CardDescription>กำหนดขีดจำกัดและเงื่อนไขการทำธุรกรรม</CardDescription>
               </CardHeader>
               <CardContent className="space-y-4">
                 <div className="space-y-2">
                   <Label htmlFor="min-deposit">ยอดฝากขั้นต่ำ (บาท)</Label>
                   <Input 
                     id="min-deposit" 
                     type="number" 
                     value={minDeposit} 
                     onChange={(e) => setMinDeposit(e.target.value)} 
                     disabled={isLoading}
                     min="0"
                   />
                 </div>
                  <div className="space-y-2">
                   <Label htmlFor="max-withdrawal">ยอดถอนสูงสุดต่อครั้ง (บาท)</Label>
                   <Input 
                     id="max-withdrawal" 
                     type="number" 
                     value={maxWithdrawal} 
                     onChange={(e) => setMaxWithdrawal(e.target.value)} 
                     disabled={isLoading}
                     min="0"
                   />
                 </div>
                 {/* Add more financial settings here */}
               </CardContent>
             </Card>
           </motion.div>
        </div>

        <motion.div 
           initial={{ opacity: 0 }}
           animate={{ opacity: 1 }}
           transition={{ delay: 0.3 }}
           className="mt-8 flex justify-end"
        >
          <Button onClick={handleSaveSettings} disabled={isLoading}>
             {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>}
             บันทึกการเปลี่ยนแปลง
          </Button>
        </motion.div>
      </div>
    </AdminLayout>
  );
};

export default AdminSettingsPage;
