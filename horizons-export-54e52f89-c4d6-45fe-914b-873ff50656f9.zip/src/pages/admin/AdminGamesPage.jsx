
import React, { useState, useEffect } from 'react';
import AdminLayout from '@/components/layout/AdminLayout';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"; // Correct import
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from '@/components/ui/card'; 
import { Badge } from '@/components/ui/badge'; 
import { motion } from 'framer-motion';
import { PlusCircle, Edit, Trash2, Loader2, Search, Gamepad2 } from 'lucide-react';

const AdminGamesPage = () => {
  const { getAllGames, addGame, updateGame, deleteGame } = useAdminAuth();
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGame, setEditingGame] = useState(null); // Null for new, object for editing
  const [isSaving, setIsSaving] = useState(false);

  const initialFormState = {
    name: '',
    description: '',
    category: '',
    minBet: '',
    maxBet: '',
    imageUrl: '', // Example image URL field
    isActive: true,
  };

  useEffect(() => {
    setLoading(true);
    try {
      setGames(getAllGames());
    } catch (error) {
      console.error("Failed to load games:", error);
    } finally {
      setLoading(false);
    }
  }, [getAllGames]);

  const filteredGames = games.filter(game =>
    game.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    game.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenDialog = (game = null) => {
    setEditingGame(game ? { ...game } : { ...initialFormState });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingGame(null); // Clear editing state
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditingGame(prev => ({ ...prev, [name]: value }));
  };

   const handleNumberInputChange = (e) => {
    const { name, value } = e.target;
     if (/^\d*$/.test(value)) {
       setEditingGame(prev => ({ ...prev, [name]: value === '' ? '' : parseInt(value) }));
     }
  };

  const handleSwitchChange = (checked) => {
     setEditingGame(prev => ({ ...prev, isActive: checked }));
  };
   const handleSelectChange = (value) => {
     setEditingGame(prev => ({ ...prev, category: value }));
  };

  const handleSaveGame = async () => {
     if (!editingGame) return;
     // Add basic validation if needed
     setIsSaving(true);
     try {
        if (editingGame.id) { // Editing existing game
           await updateGame(editingGame.id, editingGame);
        } else { // Adding new game
           await addGame(editingGame);
        }
        setGames(getAllGames()); // Refresh list
        handleCloseDialog();
     } catch (error) {
        console.error("Failed to save game:", error);
         // Toast should be shown by the hook
     } finally {
        setIsSaving(false);
     }
  };

  const handleDeleteGame = async (gameId) => {
     try {
        await deleteGame(gameId);
        setGames(games.filter(g => g.id !== gameId)); // Update state directly
     } catch (error) {
        console.error("Failed to delete game:", error);
        // Toast should be shown by the hook
     }
  };


  return (
    <AdminLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <motion.h1
             initial={{ opacity: 0, y: -20 }}
             animate={{ opacity: 1, y: 0 }}
             className="text-3xl font-bold"
          >
            จัดการเกม
          </motion.h1>
          <Button onClick={() => handleOpenDialog()}>
             <PlusCircle className="mr-2 h-4 w-4" /> เพิ่มเกมใหม่
          </Button>
        </div>

         <div className="mb-4 flex items-center">
           <div className="relative flex-1">
             <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
             <Input
               placeholder="ค้นหาเกม (ชื่อ, ประเภท)..."
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="pl-10"
             />
           </div>
        </div>


        {loading ? (
          <div className="flex justify-center items-center h-64">
             <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ชื่อเกม</TableHead>
                  <TableHead>ประเภท</TableHead>
                  <TableHead className="text-right">เดิมพัน (ต่ำสุด-สูงสุด)</TableHead>
                  <TableHead>สถานะ</TableHead>
                  <TableHead className="text-right">ดำเนินการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredGames.length === 0 ? (
                   <TableRow>
                    <TableCell colSpan={5} className="text-center h-24">ไม่พบข้อมูลเกม</TableCell>
                  </TableRow>
                ) : (
                  filteredGames.map((game) => (
                    <TableRow key={game.id}>
                      <TableCell className="font-medium">{game.name}</TableCell>
                      <TableCell className="capitalize">{game.category}</TableCell>
                      <TableCell className="text-right">฿{game.minBet} - ฿{game.maxBet}</TableCell>
                      <TableCell>
                        <Badge variant={game.isActive ? 'success' : 'secondary'}>
                           {game.isActive ? 'เปิดใช้งาน' : 'ปิดใช้งาน'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" className="mr-1" onClick={() => handleOpenDialog(game)}>
                           <Edit className="h-4 w-4" />
                        </Button>
                         <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="text-red-600 hover:text-red-700 hover:bg-red-100/50">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                             <AlertDialogContent>
                               <AlertDialogHeader>
                                 <AlertDialogTitle>ยืนยันการลบเกม?</AlertDialogTitle>
                                 <AlertDialogDescription>
                                    ต้องการลบเกม "{game.name}" ใช่หรือไม่? การกระทำนี้ไม่สามารถย้อนกลับได้
                                 </AlertDialogDescription>
                               </AlertDialogHeader>
                               <AlertDialogFooter>
                                 <AlertDialogCancel>ยกเลิก</AlertDialogCancel>
                                 <AlertDialogAction onClick={() => handleDeleteGame(game.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                    ยืนยันการลบ
                                  </AlertDialogAction>
                               </AlertDialogFooter>
                             </AlertDialogContent>
                          </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Card>
        )}

         {/* Add/Edit Game Dialog */}
         <Dialog open={isDialogOpen} onOpenChange={handleCloseDialog}>
           <DialogContent className="sm:max-w-lg">
             <DialogHeader>
               <DialogTitle>{editingGame?.id ? 'แก้ไขเกม' : 'เพิ่มเกมใหม่'}</DialogTitle>
                <DialogDescription>
                  {editingGame?.id ? `แก้ไขรายละเอียดเกม "${editingGame.name}"` : 'กรอกรายละเอียดสำหรับเกมใหม่'}
               </DialogDescription>
             </DialogHeader>
             {editingGame && (
                <div className="grid gap-4 py-4 max-h-[70vh] overflow-y-auto pr-4">
                   <div className="space-y-2">
                     <Label htmlFor="game-name">ชื่อเกม</Label>
                     <Input id="game-name" name="name" value={editingGame.name} onChange={handleInputChange} disabled={isSaving} />
                   </div>
                   <div className="space-y-2">
                     <Label htmlFor="game-description">คำอธิบาย</Label>
                     <Input id="game-description" name="description" value={editingGame.description} onChange={handleInputChange} disabled={isSaving} />
                   </div>
                   <div className="space-y-2">
                     <Label htmlFor="game-category">ประเภท</Label>
                     <Select onValueChange={handleSelectChange} value={editingGame.category} disabled={isSaving}>
                       <SelectTrigger id="game-category">
                         <SelectValue placeholder="เลือกประเภท" />
                       </SelectTrigger>
                       <SelectContent>
                         <SelectItem value="slots">สล็อต (Slots)</SelectItem>
                         <SelectItem value="card">ไพ่ (Card)</SelectItem>
                         <SelectItem value="table">เกมโต๊ะ (Table)</SelectItem>
                         <SelectItem value="other">อื่นๆ (Other)</SelectItem>
                       </SelectContent>
                     </Select>
                   </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div className="space-y-2">
                         <Label htmlFor="game-minBet">เดิมพันต่ำสุด</Label>
                         <Input id="game-minBet" name="minBet" type="number" value={editingGame.minBet} onChange={handleNumberInputChange} disabled={isSaving} />
                       </div>
                       <div className="space-y-2">
                         <Label htmlFor="game-maxBet">เดิมพันสูงสุด</Label>
                         <Input id="game-maxBet" name="maxBet" type="number" value={editingGame.maxBet} onChange={handleNumberInputChange} disabled={isSaving} />
                       </div>
                     </div>
                      <div className="space-y-2">
                         <Label htmlFor="game-imageUrl">URL รูปภาพ</Label>
                         <Input id="game-imageUrl" name="imageUrl" placeholder="https://example.com/image.jpg" value={editingGame.imageUrl || ''} onChange={handleInputChange} disabled={isSaving} />
                       </div>
                    <div className="flex items-center space-x-2 pt-2">
                       <Switch id="game-isActive" checked={editingGame.isActive} onCheckedChange={handleSwitchChange} disabled={isSaving}/>
                       <Label htmlFor="game-isActive">เปิดใช้งานเกม</Label>
                     </div>

                </div>
             )}
             <DialogFooter>
                <Button variant="outline" onClick={handleCloseDialog} disabled={isSaving}>ยกเลิก</Button>
               <Button onClick={handleSaveGame} disabled={isSaving}>
                 {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} บันทึก
               </Button>
             </DialogFooter>
           </DialogContent>
         </Dialog>

      </div>
    </AdminLayout>
  );
};

export default AdminGamesPage;
