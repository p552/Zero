
import React, { useState, useEffect, useMemo } from 'react';
import AdminLayout from '@/components/layout/AdminLayout';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Card } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { MoreHorizontal, Edit, Eye, Loader2, Search } from 'lucide-react';

// Import refactored components
import EditUserDialog from '@/components/admin/users/EditUserDialog';
import ViewUserDialog from '@/components/admin/users/ViewUserDialog';
import DeleteUserAlert from '@/components/admin/users/DeleteUserAlert';

const AdminUsersPage = () => {
  const { getAllUsers, updateUser, deleteUser } = useAdminAuth();
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedUserForEdit, setSelectedUserForEdit] = useState(null);
  const [selectedUserForView, setSelectedUserForView] = useState(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);

  const fetchUsers = () => {
    setLoading(true);
    try {
      setUsers(getAllUsers());
    } catch (error) {
      console.error("Failed to get users:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [getAllUsers]); // Dependency ensures fetch if getAllUsers changes, though unlikely

  const filteredUsers = useMemo(() => users.filter(user =>
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (user.fullName && user.fullName.toLowerCase().includes(searchTerm.toLowerCase()))
  ), [users, searchTerm]);

  const handleOpenEditDialog = (user) => {
    setSelectedUserForEdit(user);
    setIsEditDialogOpen(true);
  };

  const handleCloseEditDialog = () => {
    setIsEditDialogOpen(false);
    setSelectedUserForEdit(null);
  };

  const handleOpenViewDialog = (user) => {
    setSelectedUserForView(user);
    setIsViewDialogOpen(true);
  };

  const handleCloseViewDialog = () => {
    setIsViewDialogOpen(false);
    setSelectedUserForView(null);
  };

  const handleSaveUser = async (editedUserData) => {
    const { id, password, transactions, createdAt, ...updateData } = editedUserData;
    try {
      await updateUser(id, updateData);
      fetchUsers(); // Refresh user list after successful update
    } catch (error) {
       console.error("Failed to update user:", error);
       // Toast should be handled in the hook/context
       throw error; // Re-throw error so EditUserDialog knows save failed
    }
  };

  const handleDeleteUser = async (userId) => {
    try {
      await deleteUser(userId);
      fetchUsers(); // Refresh user list after successful deletion
    } catch (error) {
      console.error("Failed to delete user:", error);
       // Toast should be handled in the hook/context
    }
  };

  return (
    <AdminLayout>
      <div className="container mx-auto px-4 py-8">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl font-bold mb-6"
        >
          จัดการผู้ใช้
        </motion.h1>

        <div className="mb-4 flex items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="ค้นหาผู้ใช้ (ชื่อ, อีเมล)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          {/* Add New User Button can be added here if needed */}
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ชื่อผู้ใช้</TableHead>
                  <TableHead>อีเมล</TableHead>
                  <TableHead>ชื่อ-นามสกุล</TableHead>
                  <TableHead className="text-right">ยอดเงิน</TableHead>
                  <TableHead>วันที่สมัคร</TableHead>
                  <TableHead className="text-right">ดำเนินการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center h-24">ไม่พบข้อมูลผู้ใช้</TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.username}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.fullName || '-'}</TableCell>
                      <TableCell className="text-right">฿{user.balance.toLocaleString()}</TableCell>
                      <TableCell>{new Date(user.createdAt).toLocaleDateString('th-TH')}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">เปิดเมนู</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>ดำเนินการ</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleOpenViewDialog(user)}>
                              <Eye className="mr-2 h-4 w-4" /> ดูรายละเอียด
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleOpenEditDialog(user)}>
                              <Edit className="mr-2 h-4 w-4" /> แก้ไข
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DeleteUserAlert user={user} onDelete={handleDeleteUser} />
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Card>
        )}

        {/* Edit User Dialog */}
        <EditUserDialog
          user={selectedUserForEdit}
          isOpen={isEditDialogOpen}
          onClose={handleCloseEditDialog}
          onSave={handleSaveUser}
        />

        {/* View User Dialog */}
        <ViewUserDialog
          user={selectedUserForView}
          isOpen={isViewDialogOpen}
          onClose={handleCloseViewDialog}
        />
      </div>
    </AdminLayout>
  );
};

export default AdminUsersPage;
