
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Eye, EyeOff, Loader2, Lock } from 'lucide-react';

const AdminLoginPage = () => {
  const { adminLogin, currentAdmin, loading } = useAdminAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

   // Redirect if already logged in
  useEffect(() => {
    if (!loading && currentAdmin) {
      navigate('/admin');
    }
  }, [currentAdmin, loading, navigate]);


  const validateForm = () => {
    const newErrors = {};
    if (!username.trim()) newErrors.username = 'กรุณากรอกชื่อผู้ใช้แอดมิน';
    if (!password) newErrors.password = 'กรุณากรอกรหัสผ่านแอดมิน';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    
    setIsLoading(true);
    try {
      await adminLogin(username, password);
      navigate('/admin'); // Redirect on successful login
    } catch (error) {
      // Error toast is handled in adminLogin
      console.error('Admin Login error:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Prevent rendering login form if still loading auth state or already logged in
  if (loading || currentAdmin) {
     return (
       <div className="flex items-center justify-center min-h-screen bg-muted">
         <Loader2 className="h-12 w-12 animate-spin text-primary" />
       </div>
     );
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="border-primary/50 shadow-lg shadow-primary/20">
          <CardHeader className="space-y-1 text-center">
             <Lock className="h-12 w-12 mx-auto text-primary mb-4" />
            <CardTitle className="text-2xl font-bold">ระบบจัดการหลังบ้าน</CardTitle>
            <CardDescription>
              กรุณาเข้าสู่ระบบเพื่อเข้าถึงแดชบอร์ด
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">ชื่อผู้ใช้</Label>
                <Input
                  id="username"
                  placeholder="กรอกชื่อผู้ใช้แอดมิน"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={isLoading}
                />
                {errors.username && <p className="text-sm text-destructive">{errors.username}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">รหัสผ่าน</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="กรอกรหัสผ่าน"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                 {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    กำลังเข้าสู่ระบบ...
                  </>
                ) : (
                  'เข้าสู่ระบบ'
                )}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="text-center text-xs text-muted-foreground">
             &copy; {new Date().getFullYear()} Richy Game Admin Panel
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default AdminLoginPage;
