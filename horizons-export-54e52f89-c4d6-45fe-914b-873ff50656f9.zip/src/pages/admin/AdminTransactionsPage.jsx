
import React, { useState, useEffect, useMemo } from 'react';
import AdminLayout from '@/components/layout/AdminLayout';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"; // Correct import
import { Card } from '@/components/ui/card'; 
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { motion } from 'framer-motion';
import { Loader2, Search, MoreHorizontal, CheckCircle, XCircle, Clock } from 'lucide-react';


const AdminTransactionsPage = () => {
  const { getAllTransactions, updateTransactionStatus } = useAdminAuth();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [processingId, setProcessingId] = useState(null); // Track which transaction is being processed


  useEffect(() => {
    setLoading(true);
    try {
      const allTransactions = getAllTransactions();
      setTransactions(allTransactions);
    } catch (error) {
      console.error("Failed to load transactions:", error);
    } finally {
      setLoading(false);
    }
  }, [getAllTransactions]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      const matchesSearch = !searchTerm ||
                            tx.id.includes(searchTerm) ||
                            tx.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            (tx.gameName && tx.gameName.toLowerCase().includes(searchTerm.toLowerCase())) ||
                            (tx.bankAccount && tx.bankAccount.includes(searchTerm)) ||
                            (tx.accountName && tx.accountName.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesType = filterType === 'all' || tx.type === filterType;
      const matchesStatus = filterStatus === 'all' || tx.status === filterStatus;

      return matchesSearch && matchesType && matchesStatus;
    });
  }, [transactions, searchTerm, filterType, filterStatus]);


  const handleUpdateStatus = async (transactionId, userId, newStatus) => {
     setProcessingId(transactionId);
     try {
        await updateTransactionStatus(transactionId, userId, newStatus);
        // Refresh data
        setTransactions(getAllTransactions());
     } catch (error) {
        console.error(`Failed to update status for tx ${transactionId}:`, error);
        // Toast should be shown by the hook
     } finally {
        setProcessingId(null);
     }
  };


  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case 'completed': return 'success';
      case 'pending': return 'warning';
      case 'rejected': return 'danger'; // Changed from 'destructive' to match badge variants
      default: return 'secondary';
    }
  };
   const getTypeDisplay = (type) => {
     switch (type) {
        case 'deposit': return 'ฝากเงิน';
        case 'withdraw': return 'ถอนเงิน';
        case 'game': return 'เกม';
        default: return type;
     }
   };
   const getStatusDisplay = (status) => {
     switch (status) {
        case 'completed': return 'สำเร็จ';
        case 'pending': return 'รอดำเนินการ';
        case 'rejected': return 'ปฏิเสธ';
        default: return status;
     }
   };


  return (
    <AdminLayout>
      <div className="container mx-auto px-4 py-8">
        <motion.h1
           initial={{ opacity: 0, y: -20 }}
           animate={{ opacity: 1, y: 0 }}
           className="text-3xl font-bold mb-6"
        >
          จัดการธุรกรรม
        </motion.h1>

         <div className="mb-4 grid grid-cols-1 md:grid-cols-3 gap-4">
           <div className="relative md:col-span-1">
             <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
             <Input
               placeholder="ค้นหา (ID, Username, Game)..."
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="pl-10"
             />
           </div>
            <Select onValueChange={setFilterType} value={filterType}>
              <SelectTrigger>
                <SelectValue placeholder="ประเภททั้งหมด" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ประเภททั้งหมด</SelectItem>
                <SelectItem value="deposit">ฝากเงิน</SelectItem>
                <SelectItem value="withdraw">ถอนเงิน</SelectItem>
                <SelectItem value="game">เกม</SelectItem>
              </SelectContent>
            </Select>
             <Select onValueChange={setFilterStatus} value={filterStatus}>
              <SelectTrigger>
                <SelectValue placeholder="สถานะทั้งหมด" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">สถานะทั้งหมด</SelectItem>
                <SelectItem value="completed">สำเร็จ</SelectItem>
                <SelectItem value="pending">รอดำเนินการ</SelectItem>
                <SelectItem value="rejected">ปฏิเสธ</SelectItem>
              </SelectContent>
            </Select>
        </div>


        {loading ? (
          <div className="flex justify-center items-center h-64">
             <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>ผู้ใช้</TableHead>
                  <TableHead>ประเภท</TableHead>
                  <TableHead className="text-right">จำนวนเงิน</TableHead>
                  <TableHead>สถานะ</TableHead>
                  <TableHead>รายละเอียด</TableHead>
                  <TableHead>วันที่</TableHead>
                  <TableHead className="text-right">ดำเนินการ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransactions.length === 0 ? (
                   <TableRow>
                    <TableCell colSpan={8} className="text-center h-24">ไม่พบข้อมูลธุรกรรม</TableCell>
                  </TableRow>
                ) : (
                  filteredTransactions.map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell className="font-mono text-xs">{tx.id.slice(-8)}</TableCell>
                      <TableCell>{tx.username}</TableCell>
                      <TableCell>{getTypeDisplay(tx.type)}</TableCell>
                      <TableCell className={`text-right font-medium ${
                           tx.type === 'deposit' || (tx.type === 'game' && tx.result === 'win') ? 'text-green-500' :
                           tx.type === 'withdraw' || (tx.type === 'game' && tx.result === 'lose') ? 'text-red-500' : ''
                      }`}>
                        {tx.type === 'deposit' ? `+฿${tx.amount.toLocaleString()}` :
                         tx.type === 'withdraw' ? `-฿${tx.amount.toLocaleString()}` :
                         tx.type === 'game' ? (tx.result === 'win' ? `+฿${tx.winAmount.toLocaleString()} (เดิมพัน ฿${tx.betAmount})` : `-฿${tx.betAmount.toLocaleString()}`) : `฿${tx.amount.toLocaleString()}`}
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(tx.status)}>
                           {getStatusDisplay(tx.status)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs">
                         {tx.type === 'withdraw' ? `${tx.bankAccount} (${tx.accountName})` :
                          tx.type === 'game' ? tx.gameName :
                          tx.type === 'deposit' ? tx.paymentMethod : '-'}
                      </TableCell>
                       <TableCell className="text-xs">{new Date(tx.timestamp).toLocaleString('th-TH')}</TableCell>
                      <TableCell className="text-right">
                        {tx.type === 'withdraw' && tx.status === 'pending' ? (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0" disabled={processingId === tx.id}>
                                  {processingId === tx.id ? <Loader2 className="h-4 w-4 animate-spin"/> : <MoreHorizontal className="h-4 w-4" />}
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>เปลี่ยนสถานะ</DropdownMenuLabel>
                                <DropdownMenuItem onClick={() => handleUpdateStatus(tx.id, tx.userId, 'completed')}>
                                  <CheckCircle className="mr-2 h-4 w-4 text-green-500" /> อนุมัติ
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleUpdateStatus(tx.id, tx.userId, 'rejected')}>
                                   <XCircle className="mr-2 h-4 w-4 text-red-500" /> ปฏิเสธ
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                        ) : (
                           <span className="text-muted-foreground text-xs">-</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
};

export default AdminTransactionsPage;
