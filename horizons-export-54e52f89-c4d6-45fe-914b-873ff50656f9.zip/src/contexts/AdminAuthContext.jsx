
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const AdminAuthContext = createContext();

export const useAdminAuth = () => useContext(AdminAuthContext);

export const AdminAuthProvider = ({ children }) => {
  const { toast } = useToast();
  const [currentAdmin, setCurrentAdmin] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initialize admin account if it doesn't exist
    const admins = JSON.parse(localStorage.getItem('richyGameAdmins') || '[]');
    if (admins.length === 0) {
      // Create default admin account
      const defaultAdmin = {
        id: 'admin-1',
        username: 'admin',
        password: 'admin123', // In a real app, this would be hashed
        role: 'superadmin',
        createdAt: new Date().toISOString()
      };
      localStorage.setItem('richyGameAdmins', JSON.stringify([defaultAdmin]));
    }

    // Check if admin is logged in from localStorage
    const storedAdmin = localStorage.getItem('richyGameCurrentAdmin');
    if (storedAdmin) {
      try {
        setCurrentAdmin(JSON.parse(storedAdmin));
      } catch (error) {
        console.error('Error parsing stored admin:', error);
        localStorage.removeItem('richyGameCurrentAdmin');
      }
    }
    setLoading(false);
  }, []);

  // Admin login function
  const adminLogin = (username, password) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Get admin accounts
        const admins = JSON.parse(localStorage.getItem('richyGameAdmins') || '[]');
        const admin = admins.find(a => a.username === username && a.password === password);
        
        if (admin) {
          // Remove password from admin object before storing
          const { password, ...adminWithoutPassword } = admin;
          setCurrentAdmin(adminWithoutPassword);
          localStorage.setItem('richyGameCurrentAdmin', JSON.stringify(adminWithoutPassword));
          
          toast({
            title: "เข้าสู่ระบบแอดมินสำเร็จ",
            description: "ยินดีต้อนรับสู่ระบบจัดการ Richy Game",
          });
          
          resolve(adminWithoutPassword);
        } else {
          toast({
            variant: "destructive",
            title: "เข้าสู่ระบบล้มเหลว",
            description: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง",
          });
          
          reject(new Error('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'));
        }
      }, 1000);
    });
  };

  // Admin logout function
  const adminLogout = () => {
    setCurrentAdmin(null);
    localStorage.removeItem('richyGameCurrentAdmin');
    
    toast({
      title: "ออกจากระบบแอดมินสำเร็จ",
      description: "คุณได้ออกจากระบบแอดมินแล้ว",
    });
  };

  // Get all users
  const getAllUsers = () => {
    return JSON.parse(localStorage.getItem('richyGameUsers') || '[]');
  };

  // Get all transactions
  const getAllTransactions = () => {
    const users = getAllUsers();
    let allTransactions = [];
    
    users.forEach(user => {
      if (user.transactions && user.transactions.length > 0) {
        // Add username to each transaction
        const userTransactions = user.transactions.map(transaction => ({
          ...transaction,
          username: user.username,
          userId: user.id
        }));
        
        allTransactions = [...allTransactions, ...userTransactions];
      }
    });
    
    // Sort by timestamp (newest first)
    return allTransactions.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  };

  // Update transaction status
  const updateTransactionStatus = (transactionId, userId, newStatus) => {
    return new Promise((resolve, reject) => {
      try {
        // Get all users
        const users = JSON.parse(localStorage.getItem('richyGameUsers') || '[]');
        const userIndex = users.findIndex(u => u.id === userId);
        
        if (userIndex === -1) throw new Error('ไม่พบผู้ใช้');
        
        const user = users[userIndex];
        const transactionIndex = user.transactions.findIndex(t => t.id === transactionId);
        
        if (transactionIndex === -1) throw new Error('ไม่พบรายการธุรกรรม');
        
        // Update transaction status
        user.transactions[transactionIndex].status = newStatus;
        
        // If rejecting a withdrawal, refund the amount
        if (user.transactions[transactionIndex].type === 'withdraw' && newStatus === 'rejected') {
          user.balance += user.transactions[transactionIndex].amount;
        }
        
        // Update user in storage
        users[userIndex] = user;
        localStorage.setItem('richyGameUsers', JSON.stringify(users));
        
        toast({
          title: "อัปเดตสถานะธุรกรรมสำเร็จ",
          description: `ธุรกรรม #${transactionId.slice(0, 8)} ถูกเปลี่ยนเป็น ${newStatus}`,
        });
        
        resolve({ success: true });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "อัปเดตสถานะธุรกรรมล้มเหลว",
          description: error.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
        });
        
        reject(error);
      }
    });
  };

  // Update user
  const updateUser = (userId, userData) => {
    return new Promise((resolve, reject) => {
      try {
        // Get all users
        const users = JSON.parse(localStorage.getItem('richyGameUsers') || '[]');
        const userIndex = users.findIndex(u => u.id === userId);
        
        if (userIndex === -1) throw new Error('ไม่พบผู้ใช้');
        
        // Update user data
        users[userIndex] = {
          ...users[userIndex],
          ...userData
        };
        
        // Save updated users
        localStorage.setItem('richyGameUsers', JSON.stringify(users));
        
        toast({
          title: "อัปเดตผู้ใช้สำเร็จ",
          description: `ข้อมูลของผู้ใช้ ${users[userIndex].username} ได้รับการอัปเดตแล้ว`,
        });
        
        resolve({ success: true });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "อัปเดตผู้ใช้ล้มเหลว",
          description: error.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
        });
        
        reject(error);
      }
    });
  };

  // Delete user
  const deleteUser = (userId) => {
    return new Promise((resolve, reject) => {
      try {
        // Get all users
        const users = JSON.parse(localStorage.getItem('richyGameUsers') || '[]');
        const updatedUsers = users.filter(u => u.id !== userId);
        
        if (users.length === updatedUsers.length) {
          throw new Error('ไม่พบผู้ใช้');
        }
        
        // Save updated users
        localStorage.setItem('richyGameUsers', JSON.stringify(updatedUsers));
        
        toast({
          title: "ลบผู้ใช้สำเร็จ",
          description: "ผู้ใช้ถูกลบออกจากระบบแล้ว",
        });
        
        resolve({ success: true });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "ลบผู้ใช้ล้มเหลว",
          description: error.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
        });
        
        reject(error);
      }
    });
  };

  // Get system stats
  const getSystemStats = () => {
    const users = getAllUsers();
    const transactions = getAllTransactions();
    
    const totalUsers = users.length;
    const totalBalance = users.reduce((sum, user) => sum + (user.balance || 0), 0);
    const totalDeposits = transactions
      .filter(t => t.type === 'deposit' && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0);
    const totalWithdrawals = transactions
      .filter(t => t.type === 'withdraw' && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0);
    const pendingWithdrawals = transactions
      .filter(t => t.type === 'withdraw' && t.status === 'pending')
      .reduce((sum, t) => sum + t.amount, 0);
    
    return {
      totalUsers,
      totalBalance,
      totalDeposits,
      totalWithdrawals,
      pendingWithdrawals,
      newUsersToday: users.filter(u => {
        const createdDate = new Date(u.createdAt);
        const today = new Date();
        return createdDate.toDateString() === today.toDateString();
      }).length
    };
  };

  // Initialize games if they don't exist
  useEffect(() => {
    const games = JSON.parse(localStorage.getItem('richyGameGames') || '[]');
    if (games.length === 0) {
      // Create default games
      const defaultGames = [
        {
          id: 'game-1',
          name: 'Lucky Spin',
          description: 'หมุนวงล้อเพื่อลุ้นรับรางวัลใหญ่',
          category: 'slots',
          minBet: 10,
          maxBet: 1000,
          popularity: 95,
          isActive: true,
          imageUrl: '/game1.jpg'
        },
        {
          id: 'game-2',
          name: 'Royal Poker',
          description: 'เกมไพ่โป๊กเกอร์สุดคลาสสิค',
          category: 'card',
          minBet: 50,
          maxBet: 5000,
          popularity: 88,
          isActive: true,
          imageUrl: '/game2.jpg'
        },
        {
          id: 'game-3',
          name: 'Golden Dragon',
          description: 'ผจญภัยไปกับมังกรทองคำเพื่อค้นหาสมบัติ',
          category: 'slots',
          minBet: 20,
          maxBet: 2000,
          popularity: 92,
          isActive: true,
          imageUrl: '/game3.jpg'
        },
        {
          id: 'game-4',
          name: 'Baccarat Pro',
          description: 'บาคาร่าระดับมืออาชีพ',
          category: 'table',
          minBet: 100,
          maxBet: 10000,
          popularity: 97,
          isActive: true,
          imageUrl: '/game4.jpg'
        },
        {
          id: 'game-5',
          name: 'Fruit Blast',
          description: 'สล็อตผลไม้สุดสนุก',
          category: 'slots',
          minBet: 5,
          maxBet: 500,
          popularity: 85,
          isActive: true,
          imageUrl: '/game5.jpg'
        }
      ];
      localStorage.setItem('richyGameGames', JSON.stringify(defaultGames));
    }
  }, []);

  // Get all games
  const getAllGames = () => {
    return JSON.parse(localStorage.getItem('richyGameGames') || '[]');
  };

  // Add new game
  const addGame = (gameData) => {
    return new Promise((resolve, reject) => {
      try {
        // Get all games
        const games = getAllGames();
        
        // Create new game
        const newGame = {
          id: `game-${Date.now()}`,
          ...gameData,
          popularity: 0,
          isActive: true
        };
        
        // Add to games array
        games.push(newGame);
        localStorage.setItem('richyGameGames', JSON.stringify(games));
        
        toast({
          title: "เพิ่มเกมสำเร็จ",
          description: `เกม ${newGame.name} ถูกเพิ่มเข้าระบบแล้ว`,
        });
        
        resolve(newGame);
      } catch (error) {
        toast({
          variant: "destructive",
          title: "เพิ่มเกมล้มเหลว",
          description: error.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
        });
        
        reject(error);
      }
    });
  };

  // Update game
  const updateGame = (gameId, gameData) => {
    return new Promise((resolve, reject) => {
      try {
        // Get all games
        const games = getAllGames();
        const gameIndex = games.findIndex(g => g.id === gameId);
        
        if (gameIndex === -1) throw new Error('ไม่พบเกม');
        
        // Update game data
        games[gameIndex] = {
          ...games[gameIndex],
          ...gameData
        };
        
        // Save updated games
        localStorage.setItem('richyGameGames', JSON.stringify(games));
        
        toast({
          title: "อัปเดตเกมสำเร็จ",
          description: `เกม ${games[gameIndex].name} ได้รับการอัปเดตแล้ว`,
        });
        
        resolve(games[gameIndex]);
      } catch (error) {
        toast({
          variant: "destructive",
          title: "อัปเดตเกมล้มเหลว",
          description: error.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
        });
        
        reject(error);
      }
    });
  };

  // Delete game
  const deleteGame = (gameId) => {
    return new Promise((resolve, reject) => {
      try {
        // Get all games
        const games = getAllGames();
        const updatedGames = games.filter(g => g.id !== gameId);
        
        if (games.length === updatedGames.length) {
          throw new Error('ไม่พบเกม');
        }
        
        // Save updated games
        localStorage.setItem('richyGameGames', JSON.stringify(updatedGames));
        
        toast({
          title: "ลบเกมสำเร็จ",
          description: "เกมถูกลบออกจากระบบแล้ว",
        });
        
        resolve({ success: true });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "ลบเกมล้มเหลว",
          description: error.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
        });
        
        reject(error);
      }
    });
  };

  const value = {
    currentAdmin,
    loading,
    adminLogin,
    adminLogout,
    getAllUsers,
    getAllTransactions,
    updateTransactionStatus,
    updateUser,
    deleteUser,
    getSystemStats,
    getAllGames,
    addGame,
    updateGame,
    deleteGame
  };

  return (
    <AdminAuthContext.Provider value={value}>
      {children}
    </AdminAuthContext.Provider>
  );
};
