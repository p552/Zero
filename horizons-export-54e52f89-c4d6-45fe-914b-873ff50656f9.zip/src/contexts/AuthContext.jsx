
import React, { createContext, useContext } from 'react';
import { useAuthentication } from '@/hooks/useAuthentication';
import { useUserManagement } from '@/hooks/useUserManagement';
import { useTransactionManagement } from '@/hooks/useTransactionManagement';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const { currentUser, loading, login, register, logout, updateUserInStorage, users } = useAuthentication();
  const { updateProfile } = useUserManagement(currentUser, updateUserInStorage, users);
  const { deposit, withdraw, getTransactions, updateBalance } = useTransactionManagement(currentUser, updateUserInStorage, users);

  const value = {
    currentUser,
    loading,
    login,
    register,
    logout,
    updateProfile,
    deposit,
    withdraw,
    getTransactions,
    updateBalance // Expose updateBalance for direct use (like in GameDetailsPage)
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
