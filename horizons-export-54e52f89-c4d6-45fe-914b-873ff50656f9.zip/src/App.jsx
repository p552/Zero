
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { motion, AnimatePresence } from 'framer-motion';

// User Pages
import HomePage from '@/pages/HomePage';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import GamesPage from '@/pages/GamesPage';
import ProfilePage from '@/pages/ProfilePage';
import DepositPage from '@/pages/DepositPage';
import WithdrawPage from '@/pages/WithdrawPage';
import GameDetailsPage from '@/pages/GameDetailsPage';
import NotFoundPage from '@/pages/NotFoundPage';

// Admin Pages
import AdminLoginPage from '@/pages/admin/AdminLoginPage';
import AdminDashboardPage from '@/pages/admin/AdminDashboardPage';
import AdminUsersPage from '@/pages/admin/AdminUsersPage';
import AdminTransactionsPage from '@/pages/admin/AdminTransactionsPage';
import AdminGamesPage from '@/pages/admin/AdminGamesPage';
import AdminSettingsPage from '@/pages/admin/AdminSettingsPage';

// Context
import { AuthProvider } from '@/contexts/AuthContext';
import { AdminAuthProvider } from '@/contexts/AdminAuthContext';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate initial loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="w-16 h-16 mb-4 mx-auto"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e11d48" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 3h16a2 2 0 0 1 2 2v6a10 10 0 0 1-10 10A10 10 0 0 1 2 11V5a2 2 0 0 1 2-2z"></path>
              <path d="M8 10V8l4 4 4-4v2"></path>
              <path d="M15 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
              <path d="M9 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
            </svg>
          </motion.div>
          <h1 className="text-2xl font-bold text-primary">Placemakerbet</h1>
          <p className="text-muted-foreground">กำลังโหลด...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <Router>
      <AuthProvider>
        <AdminAuthProvider>
          <AnimatePresence mode="wait">
            <Routes>
              {/* User Routes */}
              <Route path="/" element={<HomePage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/games" element={<GamesPage />} />
              <Route path="/games/:id" element={<GameDetailsPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/deposit" element={<DepositPage />} />
              <Route path="/withdraw" element={<WithdrawPage />} />
              
              {/* Admin Routes */}
              <Route path="/admin_login" element={<AdminLoginPage />} />
              <Route path="/admin" element={<AdminDashboardPage />} />
              <Route path="/admin/users" element={<AdminUsersPage />} />
              <Route path="/admin/transactions" element={<AdminTransactionsPage />} />
              <Route path="/admin/games" element={<AdminGamesPage />} />
              <Route path="/admin/settings" element={<AdminSettingsPage />} />
              
              {/* 404 Route */}
              <Route path="/404" element={<NotFoundPage />} />
              <Route path="*" element={<Navigate to="/404" replace />} />
            </Routes>
          </AnimatePresence>
          <Toaster />
        </AdminAuthProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
