
import { useState, useEffect, useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';
import useLocalStorage from '@/hooks/useLocalStorage';

export function useAuthentication() {
  const { toast } = useToast();
  const [users, setUsers] = useLocalStorage('richyGameUsers', []);
  const [currentUser, setCurrentUser] = useLocalStorage('richyGameUser', null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(false); 
  }, [currentUser]);

  const login = useCallback((username, password) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const user = users.find(u => u.username === username && u.password === password); // Password check is plain text - NOT SECURE for production
        
        if (user) {
          const { password: _password, ...userWithoutPassword } = user;
          setCurrentUser(userWithoutPassword);
          toast({
            title: "เข้าสู่ระบบสำเร็จ",
            description: "ยินดีต้อนรับกลับมา!",
          });
          resolve(userWithoutPassword);
        } else {
          toast({
            variant: "destructive",
            title: "เข้าสู่ระบบล้มเหลว",
            description: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง",
          });
          reject(new Error('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'));
        }
      }, 500); // Reduced timeout
    });
  }, [users, setCurrentUser, toast]);

  const register = useCallback((userData) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (users.some(user => user.username === userData.username)) {
          toast({
            variant: "destructive",
            title: "สมัครสมาชิกล้มเหลว",
            description: "ชื่อผู้ใช้นี้มีอยู่ในระบบแล้ว",
          });
          reject(new Error('ชื่อผู้ใช้นี้มีอยู่ในระบบแล้ว'));
          return;
        }
        
        const newUser = {
          id: Date.now().toString(),
          username: userData.username,
          password: userData.password, // Store password plain text - NOT SECURE for production
          email: userData.email,
          fullName: userData.fullName,
          phoneNumber: userData.phoneNumber,
          balance: 0,
          createdAt: new Date().toISOString(),
          transactions: []
        };
        
        const updatedUsers = [...users, newUser];
        setUsers(updatedUsers);
        
        const { password, ...userWithoutPassword } = newUser;
        setCurrentUser(userWithoutPassword);
        
        toast({
          title: "สมัครสมาชิกสำเร็จ",
          description: "ยินดีต้อนรับสู่ Richy Game!",
        });
        
        resolve(userWithoutPassword);
      }, 500); // Reduced timeout
    });
  }, [users, setUsers, setCurrentUser, toast]);

  const logout = useCallback(() => {
    setCurrentUser(null);
    toast({
      title: "ออกจากระบบสำเร็จ",
      description: "ขอบคุณที่ใช้บริการ",
    });
  }, [setCurrentUser, toast]);

  const updateUserInStorage = useCallback((updatedUser) => {
     const userIndex = users.findIndex(u => u.id === updatedUser.id);
     if (userIndex !== -1) {
         const updatedUsersList = [...users];
         updatedUsersList[userIndex] = updatedUser;
         setUsers(updatedUsersList);

         // Also update currentUser if it's the same user being updated
         if (currentUser && currentUser.id === updatedUser.id) {
            const { password, ...userWithoutPassword } = updatedUser;
            setCurrentUser(userWithoutPassword);
         }
     } else {
        console.error("User not found in storage for update:", updatedUser.id);
     }
  }, [users, setUsers, currentUser, setCurrentUser]);


  return { currentUser, loading, login, register, logout, updateUserInStorage, users };
}
