
import { useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';

export function useTransactionManagement(currentUser, updateUserInStorage, users) {
  const { toast } = useToast();

  const updateBalance = useCallback((amountChange, transactionDetails) => {
    return new Promise((resolve, reject) => {
         if (!currentUser) return reject(new Error('กรุณาเข้าสู่ระบบ'));

         const userIndex = users.findIndex(u => u.id === currentUser.id);
         if (userIndex === -1) return reject(new Error('ไม่พบผู้ใช้'));

         const user = users[userIndex];
         const newBalance = user.balance + amountChange;

         if (newBalance < 0) {
             // This check might be redundant if deposit/withdraw already check, but good safeguard
             return reject(new Error('ยอดเงินไม่เพียงพอ'));
         }

         const transaction = {
             id: Date.now().toString(),
             ...transactionDetails,
             timestamp: new Date().toISOString(),
         };

         const updatedUser = {
             ...user,
             balance: newBalance,
             transactions: [transaction, ...(user.transactions || [])]
         };

         updateUserInStorage(updatedUser);
         resolve(updatedUser); // Resolve with the full updated user object
    });
  }, [currentUser, updateUserInStorage, users]);


  const deposit = useCallback((amount, paymentMethod, details) => {
    return new Promise((resolve, reject) => {
      if (amount <= 0) return reject(new Error('จำนวนเงินต้องมากกว่า 0'));
      
      updateBalance(amount, {
        type: 'deposit',
        amount: amount,
        paymentMethod: paymentMethod,
        status: 'completed',
        details: details,
      })
      .then(updatedUser => {
          toast({
            title: "ฝากเงินสำเร็จ",
            description: `เพิ่ม ${amount.toLocaleString()} บาทเข้าบัญชีของคุณแล้ว`,
          });
          resolve(updatedUser.transactions[0]); // Resolve with the latest transaction
      })
      .catch(error => {
          toast({
            variant: "destructive",
            title: "ฝากเงินล้มเหลว",
            description: error.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
          });
          reject(error);
      });
    });
  }, [updateBalance, toast]);

  const withdraw = useCallback((amount, bankAccount, accountName) => {
    return new Promise((resolve, reject) => {
       if (!currentUser) return reject(new Error('กรุณาเข้าสู่ระบบ'));
       if (amount <= 0) return reject(new Error('จำนวนเงินต้องมากกว่า 0'));
       if (amount > currentUser.balance) return reject(new Error('ยอดเงินในบัญชีไม่เพียงพอ'));
      
      // Create pending transaction first
       const pendingTransaction = {
            id: Date.now().toString(),
            type: 'withdraw',
            amount: amount,
            bankAccount: bankAccount,
            accountName: accountName,
            status: 'pending', 
            timestamp: new Date().toISOString()
        };
        
       // Optimistically deduct balance and add pending transaction
       const userIndex = users.findIndex(u => u.id === currentUser.id);
       if (userIndex === -1) return reject(new Error('ไม่พบผู้ใช้'));

       const user = users[userIndex];
       const updatedUser = {
           ...user,
           balance: user.balance - amount, // Deduct balance immediately
           transactions: [pendingTransaction, ...(user.transactions || [])]
       };
        
       updateUserInStorage(updatedUser);

       toast({
         title: "ส่งคำขอถอนเงินสำเร็จ",
         description: `คำขอถอนเงิน ${amount.toLocaleString()} บาทกำลังดำเนินการ`,
       });
       
       // Simulate admin approval/rejection later if needed
       // For now, just resolve with the pending transaction
       resolve(pendingTransaction);

    });
  }, [currentUser, updateUserInStorage, users, toast]);

  const getTransactions = useCallback(() => {
    if (!currentUser) return [];
    
    // Re-fetch the latest user data from the 'users' state managed by useAuthentication
    const latestUser = users.find(u => u.id === currentUser.id);
    return latestUser?.transactions || [];
  }, [currentUser, users]);

  return { deposit, withdraw, getTransactions, updateBalance };
}
