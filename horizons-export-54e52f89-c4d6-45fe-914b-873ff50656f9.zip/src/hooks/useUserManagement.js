
import { useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';

export function useUserManagement(currentUser, updateUserInStorage, users) {
  const { toast } = useToast();

  const updateProfile = useCallback((updatedData) => {
    return new Promise((resolve, reject) => {
      if (!currentUser) {
        reject(new Error('User not logged in'));
        return;
      }
      
      setTimeout(() => {
        try {
          const userIndex = users.findIndex(u => u.id === currentUser.id);
          if (userIndex === -1) throw new Error('ไม่พบผู้ใช้');

          // Preserve password and merge updates
          const updatedUser = {
            ...users[userIndex], 
            ...updatedData,
            password: users[userIndex].password // Ensure password isn't overwritten
          };
          
          updateUserInStorage(updatedUser);
          
          toast({
            title: "อัปเดตโปรไฟล์สำเร็จ",
            description: "ข้อมูลของคุณได้รับการอัปเดตแล้ว",
          });
          
          const { password, ...userWithoutPassword } = updatedUser;
          resolve(userWithoutPassword); // Resolve with the updated user state (no password)

        } catch (error) {
          toast({
            variant: "destructive",
            title: "อัปเดตโปรไฟล์ล้มเหลว",
            description: error.message || "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
          });
          reject(error);
        }
      }, 500); // Reduced timeout
    });
  }, [currentUser, updateUserInStorage, users, toast]);

  return { updateProfile };
}
